package org.coastal.util.io;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

public abstract class StreamHelper {

    private static final int DEFAULT_BUFFER_SIZE = 4096;

    /**
     * Copies the given <code>{@link InputStream}</code> to the given <code>{@link OutputStream}</code> but does not close either.
     * @param in
     * @param out
     * @throws IOException
     */
    public static void copy(InputStream in, OutputStream out, int bufferSize) throws IOException {
        byte[] buffer = new byte[bufferSize];
        int bytesRead;
        while ((bytesRead = in.read(buffer)) != -1) {
            out.write(buffer, 0, bytesRead);
        }
        out.flush();
    }
    
    /**
     * The same as <code>{@link #copy(InputStream, OutputStream, int)}</code> 
     * with a default buffer size of <tt>4096</tt> bytes.
     */
    public static void copy(InputStream in, OutputStream out) throws IOException {
        copy(in, out, DEFAULT_BUFFER_SIZE);
    }
}
