package org.coastal.util;

/**
 * <p>Title: LinkedAbacus</p>
 * <p>Description: Test for running Aviation Intercept Algorithms</p>
 * <p>Copyright: Copyright (c) 2003 - 2004</p>
 * <p>Company: Coastal Environmental Systems</p>
 * @author Michael Hart
 * @version 1.0
 */

public class IndexedDouble implements Comparable {
  double m_dValue;
  int    m_nIndex1;
  int    m_nIndex2;

  public IndexedDouble(double dValue, int nIndex1) {
    m_dValue  = dValue;
    m_nIndex1 = nIndex1;
    m_nIndex2 = Integer.MIN_VALUE;
  }  // End of constructor

  public IndexedDouble(double dValue, int nIndex1, int nIndex2) {
    m_dValue  = dValue;
    m_nIndex1 = nIndex1;
    m_nIndex2 = nIndex2;
  }  // End of constructor

  public double value() {
    return m_dValue;
  }  // End of method value

  public int index1() {
    return m_nIndex1;
  }  // End of method index1

  public int index2() {
    return m_nIndex2;
  }  // End of method index1

  public int compareTo(Object o) {
    IndexedDouble id      = (IndexedDouble) o;
    int           nDiff   = sign(value() - id.value());
    return nDiff == 0 ? sign(index1() - id.index1()) : nDiff;
  }  // End of method compareTo

  protected int sign(double dValue) {
    return dValue == 0.0 ? 0 : (dValue < 0.0 ? -1 : 1);
  }  // End of sign  
}  // End of method IndexedDouble
