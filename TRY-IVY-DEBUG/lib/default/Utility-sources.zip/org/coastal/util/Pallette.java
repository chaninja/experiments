package org.coastal.util;

/**
 * <p>Title: LinkedAbacus</p>
 * <p>Description: Test for running Aviation Intercept Algorithms</p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: Coastal Environmental Systems</p>
 * @author Michael Hart
 * @version 1.0
 */

import java.awt.*;

public class Pallette {
  static public final Color BACKGROUND               = Color.BLACK;
  static public final Color FOREGROUND_TEXT          = Color.WHITE;
  static public final Color ROSE_BACKGROUND          = Color.BLACK;
  static public final Color ROSE_RING                = Color.DARK_GRAY;
  static public final Color ROSE_TEXT                = Color.WHITE;
  static public final Color ROSE_POINTER             = Color.YELLOW;
  static public final Color ROSE_NO_DATA             = Color.RED;
  static public final Color INDICATOR_BACKGROUND     = Color.BLACK;
  static public final Color INDICATOR_TEXT           = Color.YELLOW;
  static public final Color INDICATOR_LABEL          = Color.LIGHT_GRAY;
  static public final Color INDICATOR_WINDOW         = Color.GRAY;
  static public final Color INDICATOR_GOOD_STATUS    = Color.GREEN;
  static public final Color INDICATOR_NO_DATA_STATUS = Color.YELLOW;
  static public final Color INDICATOR_BAD_STATUS     = Color.RED;
}  // End of class Pallette
