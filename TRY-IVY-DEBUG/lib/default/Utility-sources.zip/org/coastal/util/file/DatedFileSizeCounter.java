package org.coastal.util.file;

import java.io.File;
import java.io.FileFilter;
import java.text.DateFormat;
import java.text.DecimalFormat;
import java.text.NumberFormat;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;


/**
 * A class that can count the number and size of files that were last modified, by month, day, or hour, etc.  Originally created to calculate the size of NC AWOS logs per day.
 * @author mchristianson
 */
public class DatedFileSizeCounter {
    private static final SimpleDateFormat BUCKET_DATE_FORMAT = new SimpleDateFormat("yyyy-MM-dd");
    private static final File STARTING_DIR = new File(".");
    private static final Map<String, Long> datedFileSizeMap = new HashMap<String, Long>(); 
    private static final NumberFormat FILE_SIZE_NUMBER_FORMAT = new DecimalFormat("###,###");
    private static final String[] EXTENSIONS = new String[] {".log", ".zip"};
    
    /**
     * Main entry point.
     * @param args starting directory (where should it start counting), bucket date format (what time period to use), file extensions
     */
    public static void main(String...args) {
        System.out.println("Usage: " + DatedFileSizeCounter.class.getName() +
                " <startingDirectory> <bucketDateFormat> [fileExtension1] [fileExtension2] [fileExtensionN]"
                );
        System.out.println("Example Usage: " + DatedFileSizeCounter.class.getName() +
                " ./logs yyyy-MM-dd .log .zip"
                );
        System.out.println("The above example would count the number/size of .log and .zip files by date.");
        
        File file = STARTING_DIR;
        if(args.length >= 1) {
            file = new File(args[0]);
        }
        System.out.println("Starting in: " + file);
        
        SimpleDateFormat dateFormat = BUCKET_DATE_FORMAT;
        if(args.length >= 2) {
            dateFormat = new SimpleDateFormat(args[1]);
        }
        System.out.println("Using date format: " + dateFormat.toLocalizedPattern());
        
        String[] extensions = EXTENSIONS;
        if(args.length > 2) {
            final int length = args.length - 2;
            String[] myExtensions = new String[length];
            System.arraycopy(args, 2, myExtensions, 0, length);
            extensions = myExtensions;
        }
        
        FileExtensionFilter fileFilter = new FileExtensionFilter(extensions);
        
        process(file, fileFilter, dateFormat);
        System.out.println("There are " + datedFileSizeMap.size() + " buckets.");
        System.out.println(datedFileSizeMap);

        Set<String> dateKeys = datedFileSizeMap.keySet();
        Long grandTotal = 0L;
        for (String dateKey : dateKeys) {
            Long bucketSize = datedFileSizeMap.get(dateKey);
            System.out.println(dateKey + ": " + FILE_SIZE_NUMBER_FORMAT.format(bucketSize));

            grandTotal += bucketSize;
        }
        System.out.println("Grand total: " + FILE_SIZE_NUMBER_FORMAT.format(grandTotal));
        final int numBuckets = dateKeys.size();
        if(numBuckets > 0) {
            System.out.println("Average (for " + numBuckets + " buckets): " + FILE_SIZE_NUMBER_FORMAT.format(grandTotal/numBuckets));
        }
    }
    
    public static void process(File theFile, FileExtensionFilter fileFilter, DateFormat bucketNameDateFormat) {
        if(theFile.isDirectory()) {
            System.out.println("Processing " + theFile);
            //it's a directory, so get the list of files for this directory
            File[] files = theFile.listFiles(fileFilter);
            for (File file : files) {
                //process the file (without respect to dir vs. file) 
                process(file, fileFilter, bucketNameDateFormat);
            }
        } else {
            //it's a file, so get the last modified date
            Date fileDate = new Date(theFile.lastModified());
            //get the key for the bucket, using the date format
            String bucketNameForFile = bucketNameDateFormat.format(fileDate);
            //get the current size of the bucket
            Long bucketSize = datedFileSizeMap.get(bucketNameForFile);
            if(bucketSize == null) {
                //the bucket for this date doesn't exist, so start at 0
                bucketSize = 0L;
            }
            //calculate the new bucket size
            long newBucketSize = bucketSize + theFile.length();
            //store the new bucket size
            datedFileSizeMap.put(bucketNameForFile, newBucketSize);
        }
    }

    private static class FileExtensionFilter implements FileFilter {
        private final String[] extensions;

        public FileExtensionFilter(String[] extensions) {
            this.extensions = extensions;
            System.out.println("FileFilter: " + Arrays.toString(extensions));
        }
        
        public boolean accept(File f) {
            String fLow = f.getName().toLowerCase();
            boolean accept = f.isDirectory();
            if(!accept) {
                for (String extension : extensions) {
                    if(fLow.endsWith(extension)) {
                        accept = true;
                        break;
                    }
                }
            }
            return accept;
        }        
    }
}

