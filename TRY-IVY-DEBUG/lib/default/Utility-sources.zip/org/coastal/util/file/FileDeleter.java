package org.coastal.util.file;

import java.io.File;
import java.io.FileFilter;
import java.io.IOException;
import java.util.Arrays;
import java.util.Calendar;
import java.util.regex.Pattern;
import java.util.regex.PatternSyntaxException;

import org.apache.log4j.BasicConfigurator;
import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.coastal.util.file.LastModifiedAndFilenameFileFilter.DirectoryMode;

/**
 * A utility class for deleting files.  Can be configured to crawl any number of directories to search for and delete files using a <code>{@link FileFilter}</code>.
 * @author mchristianson
 *
 */
public class FileDeleter implements Runnable {
    private final static Logger logger = Logger.getLogger(FileDeleter.class);
    private final static FileFilter DIRECTORY_FILE_FILTER = DirectoryFileFilter.getInstance();
    private final DeleteMode deleteMode;

    /** the directories to crawl */
    private File[] directories;
    /** used for finding files that qualify for deletion */
    private FileFilter filter;

    public enum DeleteMode {DELETE, LEAVE};

    /**
     * Constructs a <code>FileDeleter</code> which will delete files using the given <code>FileFilter</code> when <code>{@link #run()}</code> is called.
     * <p/>
     * Example usage 1:
     * <pre>
     * new FileDeleter(directories, fileFilter, DeleteMode.DELETE, DirectoryMode.LEAVE).run();
     * </pre>
     *
     * Example usage 2:
     * <pre>
     * Runnable runnable = new FileDeleter(directories, fileFilter, DeleteMode.DELETE, DirectoryMode.LEAVE);
     * Thread t = new Thread(runnable);
     * t.start();
     * </pre>
     * 
     * Example usage 3: 
     * <pre>
     * final Runnable runnable = new FileDeleter(directories, fileFilter, DeleteMode.DELETE, DirectoryMode.LEAVE);
     *
     * Timer timer = new Timer();
     * timer.scheduleAtFixedRate(new TimerTask() {
     *     public void run() {
     *         runnable.run();
     *     }
     * }, delay, period);
     * </pre>
     * @param directories directories to crawl
     * @param filter determines which files qualify for deletion
     * @param deleteMode mode for deleting files
     * @param directoryRemoval mode for deleting empty directories
     */
    public FileDeleter(File[] directories, FileFilter filter, DeleteMode deleteMode) {
        if(directories == null || directories.length == 0) {
            throw new IllegalArgumentException("directories must be non-null and non-empty");
        }
        this.directories = directories;

        if(filter == null) {
            throw new IllegalArgumentException("filter must be non-null");
        }
        this.filter = filter;
        logger.info("Using filter: " + filter);

        if(deleteMode == null) {
            throw new IllegalArgumentException("deleteMode must be non-null");
        }
        this.deleteMode = deleteMode;
    }

    public void run() {
        logger.info("Running");
        long numDeleted = 0L;
        for (File directory : directories) {
            logger.debug("Starting " + directory.getAbsolutePath());
            numDeleted += processDirectory(directory, filter, deleteMode);
        }
        logger.info("Finished, deleted " + numDeleted);
    }

    /**
     * Processes a directory recursively.
     * @param file the directory to process
     * @param filter the <code>FileFilter</code> to use when filtering for files
     * @param deleteMode the <code>{@link DeleteMode}</code>
     */
    private static long processDirectory(File directory, FileFilter filter, DeleteMode deleteMode) {
        long numDeleted = 0L;
        logger.debug("Processing " + directory + " (directory)");
        if (directory.isDirectory()) {
            File[] subDirectories = directory.listFiles(DIRECTORY_FILE_FILTER);
            logger.debug("Found " + subDirectories.length + " subdirectories");
            numDeleted += processDirectories(subDirectories, filter, deleteMode);
            
            File[] files = directory.listFiles(filter);
            logger.debug("Found " + files.length + " using filter");
            numDeleted += process(files, deleteMode);
        }
        return numDeleted;
    }

    /**
     * Convenience method for processing an array of directories.
     */
    private static long processDirectories(File[] directories, FileFilter filter, DeleteMode deleteMode) {
        long numDeleted = 0L;
        for (File directory : directories) {
            if(directory.isDirectory()) {
                numDeleted += processDirectory(directory, filter, deleteMode);
            }
        }
        return numDeleted;
    }

    /**
     * Convenience method for processing an array of <code>File</code>s.
     */
    private static long process(File[] files, DeleteMode deleteMode) {
        long numDeleted = 0L;
        for (File f : files) {
            numDeleted += delete(f, deleteMode);
        }
        return numDeleted;
    }

    /**
     * Deletes a file or directory.
     * @param file the <code>File</code> to delete
     * @param deleteMode the <code>{@link DeleteMode}</code>
     * @return
     */
    private static long delete(File file, DeleteMode deleteMode) {
        long numDeleted = 0L;

        logger.debug("Deleting " + file + (file.isDirectory() ? " (directory)" : ""));
        if (DirectoryHelper.isEmpty(file)) {

            switch (deleteMode) {
            case DELETE:
                if (file.delete()) {
                    numDeleted++;
                    logDelete(logger, Level.DEBUG, file);
                } else {
                    logger.warn("Could not delete " + file);
                }
                break;
            case LEAVE:
                if (logger.isDebugEnabled()) {
                    logger.debug("(dry run delete)");
                }
                numDeleted++;
                logDelete(logger, Level.DEBUG, file);
                break;
            }
        }
        return numDeleted;
    }

    private static void logDelete(Logger logger, Level level, File file) {
        logger.log(level, "Deleted " + file);
    }
    
    /**
     * Entry point for test and example usage.
     * @throws IOException 
     */
    public static void main(String...args) throws InterruptedException, IOException {
        BasicConfigurator.configure();
        Logger.getRootLogger().setLevel(Level.DEBUG);
        
        if(args.length < 5) {
            logger.fatal("Usage: " + FileDeleter.class.getName() + " <days> <regex> <dirMode> <delMode> <dir1 dir2 ... dirN>");
            logger.info("Example: " + FileDeleter.class.getName() + " -30 (?i).*\\.(zip) DELETE DELETE ./logs");
            logger.info("Above example deletes all .zip files older than 30 days from the log directory.");
            logger.info("Options for dirMode: " + Arrays.toString(DirectoryMode.values()));
            logger.info("Options for delMode: " + Arrays.toString(DeleteMode.values()));
            logger.info("For a dry run, try using dirMode = LEAVE and delMode = LEAVE");
            System.exit(1);
        }
        
        int days = Integer.valueOf(args[0]);
        if(days > -1) {
            logger.fatal("The number of days must be negative (otherwise you'll delete everything!)");
            System.exit(1);
        } 
        
        String patternStr = args[1];
        Pattern pattern = null;
        try {
            pattern = Pattern.compile(patternStr);
        } catch(PatternSyntaxException pse) {
            logger.fatal("The regular expression is invalid", pse);
            System.exit(1);
        }
        
        DirectoryMode dirMode = DirectoryMode.valueOf(args[2]);
        DeleteMode delMode = DeleteMode.valueOf(args[3]); 
        
        String[] dirNames = new String[0];
        if(args.length > 4) {
            final int length = args.length - 4;
            String[] myDirNames = new String[length];
            System.arraycopy(args, 4, myDirNames, 0, length);
            dirNames = myDirNames;
        }
        File[] dirs = new File[dirNames.length];
        for (int i = 0; i < dirNames.length; i++) {
            dirs[i] = new File(dirNames[i]);
        }
        
        final Runnable runnable = new FileDeleter(dirs, 
                new LastModifiedAndFilenameFileFilter(Calendar.DATE, days, pattern, dirMode), 
                delMode);
        logger.debug(runnable.toString());
        runnable.run();
    }

    /**
     * @generated by CodeSugar http://sourceforge.net/projects/codesugar */
    public String toString() {
        StringBuffer buffer = new StringBuffer();
        buffer.append("[FileDeleter:");
        buffer.append(" deleteMode: ");
        buffer.append(deleteMode);
        buffer.append(" { ");
        for (int i0 = 0; directories != null && i0 < directories.length; i0++) {
            buffer.append(" directories[" + i0 + "]: ");
            buffer.append(directories[i0]);
        }
        buffer.append(" } ");
        buffer.append(" filter: ");
        buffer.append(filter);
        buffer.append("]");
        return buffer.toString();
    }
}
