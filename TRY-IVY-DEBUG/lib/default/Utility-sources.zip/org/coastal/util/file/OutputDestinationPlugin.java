package org.coastal.util.file;
import ghm.follow.OutputDestination;

import java.util.Properties;

/**
 * Instances of this class are used by <code>{@link FileWatcher}</code> to receive
 * the contents of a file being watched. 
 * @author mchristianson
 *
 */
public abstract class OutputDestinationPlugin implements OutputDestination {
    /* (non-Javadoc)
     * @see ghm.follow.OutputDestination#clear()
     */
    public abstract void clear();
    
    /* (non-Javadoc)
     * @see ghm.follow.OutputDestination#print(java.lang.String)
     */
    public abstract void print(String s);
    
    /**
     * Sets the <code>Properties</code>.
     * @param properties
     * @throws OutputDestinationPluginConfigurationException
     */
    public abstract void setProperties(Properties properties) throws OutputDestinationPluginConfigurationException;
    
    /**
     * Initializer.
     * @throws OutputDestinationPluginConfigurationException
     */
    public abstract void init() throws OutputDestinationPluginConfigurationException;
}
