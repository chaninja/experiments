package org.coastal.util.file;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.security.DigestInputStream;
import java.security.MessageDigest;
import java.util.ArrayList;

/**
 * An utility class that copies files to a backup folder and generate
 * a digest file for verification.
 * 
 * To use it, a caller should call setter methods to provide files and
 * backup folder, then call backup() method to do the solid work.
 * 
 * The digest file name and algorithm are optional. They have default
 * values.
 * 
 * @author ryoung
 * 
 */
public class BackupFiles {
	static public final String DEFAULT_DIGEST_FILENAME	= "backup_digest.txt";
	static public final String DEFAULT_DIGEST_ALGORITHM	= "SHA";
	
	static final String FILE_TAG	= "FILE=";
	static final String DIGEST_TAG	= "DIGEST=";
	static final String DELIMITER	= ",";
	
	static public final int OK = 0;
	
	static public final int INVALID_PARAMETERS		= 100;
	static public final int CANNOT_READ_ORIGINALS	= 110;
	static public final int CANNOT_WRITE_BACKUPS	= 120;
	
	// input parameters
	private File[] srcFiles;
	private File backupFolder;
	private String digestFname = DEFAULT_DIGEST_FILENAME;
	private String digestAlg = DEFAULT_DIGEST_ALGORITHM;
	
	// internal variables
	private File[] backupFiles;
	private File digestFile;
	private byte[] digestChecksum; 	
	
	
	/**
	 * Set files to be copied.
	 * 
	 * @param files files to be copied must exist and readable.
	 */
	public void setSourceFiles(File[] files) {
		srcFiles = files;
	}
	
	/**
	 * Set backup folder where files are copied into.
	 * 
	 * @param folder files will be copied to the backup folder.
	 */
	public void setBackupFolder(File folder) {
		backupFolder = folder;
	}
	
	/**
	 * Set digest file, which contains the list of copied files and 
	 * a digest generated from all files.
	 * 
	 * @param name digest file name, which will be created in the backup folder.
	 * 				default value is backup_digest.txt
	 */
	public void setDigestFilename(String name) {
		digestFname = name.trim();
	}
	
	/**
	 * Set algorithm for digest.
	 * 
	 * @param name name of algorithm for digest. default value is SHA.
	 * @see MessageDigest.getInstance()
	 */
	public void setDigestAlgorithm(String name) {
		digestAlg = name.trim();
	}
	
	/**
	 * Copy files to backup folder and generate a digest file.
	 * 
	 * @return
	 */
	public int backup() {
		int code = checkParameters();
		if(code != OK)
			return code;
		
		code = createInternalVaribles();
		if(code != OK)
			return code;
		
		code = removeExistingBackups();
		if(code != OK)
			return code;
		
		code = copyOriginalsToBackups();
		if(code != OK)
			return code;
		
		code = createDigestFile();
		if(code != OK)
			return code;
		
		return OK;
	}
	
	private int checkParameters() {
		ArrayList<File> srcFolders = new ArrayList<File>();
		ArrayList<String> srcFnames = new ArrayList<String>();
		
		if(srcFiles == null || srcFiles.length == 0)
			return INVALID_PARAMETERS;
		
		for(File file : srcFiles) {
			if(!file.isFile() || !file.canRead())
				return INVALID_PARAMETERS;
			
			String fname = file.getName().toLowerCase();
			if(!srcFnames.contains(fname))
				srcFnames.add(fname);
			else
				return INVALID_PARAMETERS;
			
			File parentFolder = file.getParentFile();
			if(!srcFolders.contains(parentFolder))
				srcFolders.add(parentFolder);
		}
		
		if(backupFolder == null)
			return INVALID_PARAMETERS;
		
		if(!backupFolder.isDirectory() || !backupFolder.canWrite())
			return INVALID_PARAMETERS;
		
		if(srcFolders.contains(backupFolder))
			return INVALID_PARAMETERS;
		
		if(digestFname == null || digestFname.length() == 0)
			return INVALID_PARAMETERS;
		
		// digestAlg will be checked when generating digest from original files
		
		return OK;
	}
	
	private int createInternalVaribles() {
		digestFile = new File(backupFolder, digestFname);
		
		backupFiles = new File[srcFiles.length];
		for(int n = 0; n < srcFiles.length; n++) {
			backupFiles[n] = new File(backupFolder, srcFiles[n].getName());
		}
		
		// generate digest from original files
		MessageDigest digest;
		try {
			digest = MessageDigest.getInstance(digestAlg);
		} catch (Exception e) {
			return INVALID_PARAMETERS;
		}
		
		for(File file : srcFiles) {
			InputStream fin = null;
			
			try {
				fin = new DigestInputStream(new FileInputStream(file), digest);
				byte[] buf = new byte[1024 * 4];
				while(fin.read(buf, 0, buf.length) > -1)
				{}
			} catch (Exception e) {
				return CANNOT_READ_ORIGINALS;
			} finally {
				if(fin != null) {
					try {
						fin.close();
					} catch (Exception e) {
						// silently
					}
				}
			}
		}
		
		digestChecksum = digest.digest();
		
		return OK;
	}
	
	private int removeExistingBackups() {
		if(digestFile.exists()) {
			if(!digestFile.delete())
				return CANNOT_WRITE_BACKUPS;
		}
		
		for(File file : backupFiles) {
			if(file.exists()) {
				if(!file.delete())
					return CANNOT_WRITE_BACKUPS;
			}
		}
		
		return OK;
	}
	
	private int copyOriginalsToBackups() {
		for(int n = 0; n < srcFiles.length; n++) {
			int code = copyFile(srcFiles[n], backupFiles[n]);
			if(code != OK)
				return code;
		}
		
		return OK;
	}
	
	private int copyFile(File frFile, File toFile) {
		InputStream fin = null;
		OutputStream fout = null;
		
		try {
			fin = new FileInputStream(frFile);
			fout = new FileOutputStream(toFile);
			
			byte[] buf = new byte[1024 * 4];
			
			while(true) {
				int readSize = fin.read(buf, 0, buf.length);
				if(readSize == -1)
					break;
				
				fout.write(buf, 0, readSize);
			}
		} catch (Exception e) {
			return CANNOT_WRITE_BACKUPS;
		} finally {
			if(fin != null) {
				try {
					fin.close();
				} catch (Exception e) {
					// silently
				}
			}
			if(fout != null) {
				try {
					fout.close();
				} catch (Exception e) {
					// silently
				}
			}
		}
		
		return OK;
	}
	
	private int createDigestFile() {
		PrintWriter fout = null;
		try {
			fout = new PrintWriter(digestFile);
			
			for(File file : srcFiles) {
				//use relative path on the sourcefile. This will solve the problem 
				//when the backup was done on a different version of NCAWOS than the restore.
				String fullName = file.getAbsolutePath();
				fullName = fullName.replaceAll(".*\\\\conf", ".\\\\conf");

				fout.println(FILE_TAG + fullName);
			}
			
			fout.print(DIGEST_TAG + digestAlg);
			for(byte b : digestChecksum) {
				fout.print(DELIMITER + b);
			}
			
			if(fout.checkError())
				return CANNOT_WRITE_BACKUPS;
		} catch (Exception e) {
			return CANNOT_WRITE_BACKUPS;
		} finally {
			if(fout != null)
				fout.close();
		}
		
		return OK;
	}
	
}
