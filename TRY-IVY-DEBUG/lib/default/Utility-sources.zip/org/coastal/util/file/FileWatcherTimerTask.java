package org.coastal.util.file;

import java.io.File;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Properties;
import java.util.Timer;
import java.util.TimerTask;

import org.apache.log4j.Logger;

/**
  This <code>{@link TimerTask}</code> is composed of a <code>{@link FileWatcher}</code> 
  which is stopped and started on a regular basis in order to watch files that 
  change names over time (for example, dated log files).  Example usage:
  
  <pre>
  Timer t = new Timer();
  LogFileWatcherTimerTask task = new LogFileWatcherTimerTask(logFileWatcher);
  t.scheduleAtFixedRate(task, delay, period);
  </pre>
  
  In the above example, the <code>period</code> shouldn't be too long if the
  file you are watching changes name frequently.  For example, don't use a period
  of one day if your filename changes every hour.

  <p/>
  
  <em>Note</em>: it's OK if the file being watched doesn't (yet) exist because
  this class will keep trying to watch the file based on the scheduled <code>period</code>.  (Another
  good reason not to have a huge <code>period</code>.) 
  @author mchristianson
  @see Timer
  @see TimerTask
 */
public class FileWatcherTimerTask extends TimerTask {
    private final static Logger logger = Logger.getLogger(FileWatcherTimerTask.class);
    private FileWatcher logFileWatcher;  //the composed LogFileWatcher we stop and start
    private final DateFormat logFileFilenameDateFormat;
    private File fileBeingWatched = null;
    private boolean interrupted = false;

    /**
     * Constructs an instance of this class with the given <code>{@link FileWatcher}</code>.
     * The <code>{@link FileWatcher}</code> should be passed in <em>without</em> having called
     * <code>{@link FileWatcher#init()}</code>.  Also, the <code>{@link FileWatcher}</code> should
     * not be shared with any other classes because its <code>Properties</code> will be changed
     * during the lifetime of this instance.   
     */
    public FileWatcherTimerTask(FileWatcher logFileWatcher) {
        this.logFileWatcher = logFileWatcher;
        Properties lfwProps = logFileWatcher.getProperties();
        String filenameFormatStr = lfwProps.getProperty("filenameFormat");
        logFileFilenameDateFormat = new SimpleDateFormat(filenameFormatStr);
        logger.info("log filename date format: " + filenameFormatStr);
    }

    @Override
    public void run() {
        logger.debug("run()");
        logger.debug("File currently being watched: " + (fileBeingWatched == null ? "none yet" : fileBeingWatched));

        String filename = logFileFilenameDateFormat.format(new Date());
        File newFile = new File(filename);
        logger.debug("Based on filename date format, the current time's file to watch is: " + newFile);

        try {
            if(timeToSwitchFiles(fileBeingWatched, newFile)) {
                logger.debug("Time to switch files; will stopAndWait(), change filename, then init()");
                logFileWatcher.stopAndWait();
                
                if(newFile.exists() && newFile.canRead()) {
                    logger.debug("New file exists; switching");
                    Properties properties = logFileWatcher.getProperties();
                    properties.setProperty("filename", filename);
                    logFileWatcher.setProperties(properties);
                    logFileWatcher.init();
                    fileBeingWatched = newFile;
                } else {
                    logger.warn("Can't read from file: " + newFile);
                }
            } else {
                logger.debug("Not time to switch files yet");
            }
        } catch (InterruptedException e) {
            interrupted = true;
            // fall through
        } catch (OutputDestinationPluginConfigurationException e) {
            logger.error("An OutputDestinationPlugin had a configuration problem", e);
        } finally {
            if (interrupted)
                Thread.currentThread().interrupt();
        }
    }

    private static boolean timeToSwitchFiles(File fileBeingWatched, File newFile) {
        return fileBeingWatched == null || !fileBeingWatched.equals(newFile);
    }

}
