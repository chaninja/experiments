package org.coastal.util;

/**
 * <p>Title: LinkedAbacus</p>
 * <p>Description: Test for running Aviation Intercept Algorithms</p>
 * <p>Copyright: Copyright (c) 2003 - 2004</p>
 * <p>Company: Coastal Environmental Systems</p>
 * @author Michael Hart
 * @version 1.0
 */

public class ConvertDistance extends ConvertUnits {
  public final int MILLIMETERS    = 0;
  public final int CENTIMETERS    = 1;
  public final int DECIMETERS     = 2;
  public final int METERS         = 3;
  public final int KILOMETERS     = 4;
  public final int INCHES         = 5;
  public final int FEET           = 6;
  public final int YARDS          = 7;
  public final int MILES          = 8;
  public final int NAUTICAL_MILES = 9;
  public final int PER_KILOMETERS = 10;
  public final int PER_MILES      = 11;
  public final int PER_METERS     = 12;
  final String []  m_rgsUnitsNames      = {
    "mm", "cm", "dm", "m", "km", "inches", "ft", "yds", "mi", "nmi", "1/km",
    "1/mi", "1/m" 
  };

  public int numberOfUnitNames() {
    return m_rgsUnitsNames.length;
  }  // End of method numberOfUnitNames

  public String unitName(int nIndex) {
    String sName = "";
    if(nIndex >= 0 && nIndex < numberOfUnitNames()) {
      sName = m_rgsUnitsNames[nIndex];
    }  // End of if statement.
    return sName;
  }  // End of method unitName

  public double convert(double dDistance, int nOldUnitsID, int nNewUnitsID) {
    double dConverted = dDistance;

    if (nOldUnitsID == nNewUnitsID) {
    	return dConverted;
    }
   
    // Convert old value into millimeters
    switch (nOldUnitsID) {
      case MILLIMETERS: {
        if(isPerUnits(nNewUnitsID)) {
          dConverted = Double.NaN;
        }  // End of else statement.
        break;        
      }  // End of case statement.

      case CENTIMETERS: {
        if(isPerUnits(nNewUnitsID)) {
          dConverted = Double.NaN;
        }
        else {
          dConverted *= 10.0;
        }  // End of else statement.
        break;
      }  // End of case statement.

      case DECIMETERS: {
        if(isPerUnits(nNewUnitsID)) {
          dConverted = Double.NaN;
        }
        else {
          dConverted *= 100.0;
        }  // End of else statement.
        break;
      }  // End of case statement.

      case METERS: {
        if(isPerUnits(nNewUnitsID)) {
          dConverted = Double.NaN;
        }
        else {
          dConverted *= 1000.0;
        }  // End of else statement.
        break;
      }  // End of case statement.

      case KILOMETERS: {
        if(isPerUnits(nNewUnitsID)) {
          dConverted = Double.NaN;
        }
        else {
          dConverted *= 1000.0 * 1000.0;
        }  // End of else statement.
        break;
      }  // End of case statement.

      case INCHES: {
        if(isPerUnits(nNewUnitsID)) {
          dConverted = Double.NaN;
        }
        else {
          dConverted *= 25.4;
        }  // End of else statement.
        break;
      }  // End of case statement.

      case FEET: {
        if(isPerUnits(nNewUnitsID)) {
          dConverted = Double.NaN;
        }
        else {
          dConverted *= 12.0 * 25.4;
        }  // End of else statement.
        break;        
      }  // End of case statement.

      case YARDS: {
        if(isPerUnits(nNewUnitsID)) {
          dConverted = Double.NaN;
        }
        else {
          dConverted *= 3.0 * 12.0 * 25.4;
        }  // End of else statement.
        break;        
      }  // End of case statement.

      case MILES: {
        if(isPerUnits(nNewUnitsID)) {
          dConverted = Double.NaN;
        }
        else {
          dConverted *= 5280.0 * 12.0 * 25.4;
        }  // End of else statement.
        break;        
      }  // End of case statement.

      case NAUTICAL_MILES: {
        if(isPerUnits(nNewUnitsID)) {
          dConverted = Double.NaN;
        }
        else {
          dConverted *= 6076.1155 * 12.0 * 25.4;
        }  // End of else statement.
        break;        
      }  // End of case statement. 

      case PER_KILOMETERS: {
        if(!isPerUnits(nNewUnitsID)) {
          dConverted = Double.NaN;
        }  // End of else statement.
        break;        
      }  // End of case statement.

      case PER_MILES: {
        if(isPerUnits(nNewUnitsID)) {
          dConverted /= 1.609344;
        }
        else {
          dConverted = Double.NaN;
        }  // End of else statement.
        break;        
      }  // End of case statement.

      case PER_METERS: {
        if(isPerUnits(nNewUnitsID)) {
          dConverted *= 1000.0;
        }  // End of else statement.
        else {
          dConverted = Double.NaN;
        }  // End of if statement.
        break;        
      }  // End of case statement.
    }  // End of switch statement.

    if(!Double.isNaN(dConverted)) {
      switch (nNewUnitsID) {
        case MILLIMETERS: {
          if (isPerUnits(nOldUnitsID)) {
            dConverted = Double.NaN;
          } // End of else statement.
          break;
        } // End of case statement.

        case CENTIMETERS: {
          if (isPerUnits(nOldUnitsID)) {
            dConverted = Double.NaN;
          }
          else {
            dConverted /= 10.0;
          } // End of else statement.
          break;
        } // End of case statement.

        case DECIMETERS: {
          if (isPerUnits(nOldUnitsID)) {
            dConverted = Double.NaN;
          }
          else {
            dConverted /= 100.0;
          } // End of else statement.
          break;
        } // End of case statement.

        case METERS: {
          if (isPerUnits(nOldUnitsID)) {
            dConverted = Double.NaN;
          }
          else {
            dConverted /= 1000.0;
          } // End of else statement.
          break;
        } // End of case statement.

        case KILOMETERS: {
          if (isPerUnits(nOldUnitsID)) {
            dConverted = Double.NaN;
          }
          else {
            dConverted /= 1000.0 * 1000.0;
          } // End of else statement.
          break;
        } // End of case statement.

        case INCHES: {
          if (isPerUnits(nOldUnitsID)) {
            dConverted = Double.NaN;
          }
          else {
            dConverted /= 25.4;
          } // End of else statement.
          break;
        } // End of case statement.

        case FEET: {
          if (isPerUnits(nOldUnitsID)) {
            dConverted = Double.NaN;
          }
          else {
            dConverted /= (12.0 * 25.4);
          } // End of else statement.
          break;
        } // End of case statement.

        case YARDS: {
          if (isPerUnits(nOldUnitsID)) {
            dConverted = Double.NaN;
          }
          else {
            dConverted /= (3.0 * 12.0 * 25.4);
          } // End of else statement
          break;
        } // End of case statement.

        case MILES: {
          if (isPerUnits(nOldUnitsID)) {
            dConverted = Double.NaN;
          }
          else {
            dConverted /= (5280.0 * 12.0 * 25.4);
          } // End of else statement.
          break;
        } // End of case statement.

        case NAUTICAL_MILES: {
          if (isPerUnits(nOldUnitsID)) {
            dConverted = Double.NaN;
          }
          else {
            dConverted /= (6076.1155 * 12.0 * 25.4);
          } // End of else statement.
          break;
        } // End of case statement.

        case PER_KILOMETERS: {
          if (!isPerUnits(nOldUnitsID)) {
            dConverted = Double.NaN;
          } // End of else statement.
          break;
        } // End of case statement.

        case PER_MILES: {
          if (isPerUnits(nOldUnitsID)) {
            dConverted *= 1.609344;
          }
          else {
            dConverted = Double.NaN;
          } // End of else statement.
          break;
        } // End of case statement.

        case PER_METERS: {
          if (isPerUnits(nOldUnitsID)) {
            dConverted /= 1000.0;
          }
          else {
            dConverted = Double.NaN;
          } // End of else statement.
          break;
        }  // End of case statement.
      } // End of switch statement.
    }  // End of if statement.

    return dConverted;
  }  // End of method convert

  private boolean isPerUnits(int nUnitCode) {
    return nUnitCode == PER_KILOMETERS || nUnitCode == PER_MILES ||
      nUnitCode == PER_METERS;
  }  // End of method isPerUnits
}  // End of ConvertDistance
