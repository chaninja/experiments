package org.coastal.util;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;


/**
 * Helps load <code>Properties</code> files.  Example usage:
 * <pre>
 * try {
 *     Properties properties = PropertiesLoader.load(filename);
 * } catch (IOException ioe) {
 *     //handle exception
 * }
 * </pre>
 * 
 * @author mchristianson
 */
public abstract class PropertiesLoader {
    private final static Log logger = LogFactory.getLog(PropertiesLoader.class);
    
    /**
     * Loads a <code>Properties</code> file from the specified resource 
     * (such as a file on the <code>classpath</code>) using <code>getResourceAsStream()</code>.  
     * The search order is described in the documentation for 
     * <code>{@link java.lang.ClassLoader#getResource(String)}</code>. 
     * 
     * @param resourceName the resource name
     * @return the loaded <code>Properties</code>
     * @exception  IOException if an error occurred when reading from the
     *               input stream.
     * @throws     IllegalArgumentException if the input stream contains a
     *         malformed Unicode escape sequence.
     * @see ClassLoader
     * @see ClassLoader#getResource(String)
     */
    public static Properties load(final String resourceName) throws IOException {
        logger.info("Attempting to load Properties file as a resource: " + resourceName);
        InputStream resourceAsStream = Thread.currentThread().getContextClassLoader().getResourceAsStream(resourceName);
        Properties properties = new Properties();
        properties.load(resourceAsStream);
        return properties;
    }
    
    /**
     * Loads a <code>Properties</code> file from the specified <code>File</code>.
     * 
     * @param file the <code>File</code>
     * @return the loaded <code>Properties</code>
     * @exception  IOException if an error occurred when reading from the file.
     */
    public static Properties load(final File file) throws IOException {
        logger.info("Attempting to load Properties file as a FileInputStream: " + file.getAbsolutePath());
        Properties properties = new Properties();
        properties.load(new FileInputStream(file));
        return properties;
    }
}
