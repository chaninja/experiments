package org.coastal.util.file;


import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.Writer;
import java.util.Calendar;
import java.util.regex.Pattern;

import junit.framework.TestCase;

import org.apache.log4j.BasicConfigurator;
import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.coastal.util.file.FileDeleter;
import org.coastal.util.file.LastModifiedAndFilenameFileFilter;
import org.coastal.util.file.FileDeleter.DeleteMode;
import org.coastal.util.file.LastModifiedAndFilenameFileFilter.DirectoryMode;


public class TestFileDeleter extends TestCase {
    private final static Logger logger = Logger.getLogger(TestFileDeleter.class);

    private final File here = new File("./" + TestFileDeleter.class.getName());
    private final File freshdir = new File(here, "fresh");
    private final File freshfile = new File(freshdir, "do.not.delete.file");
    private final File olddir = new File(here, "old");
    private final File oldfile = new File(olddir, "delete.file");

    private Runnable runnable;
    
    private static void createEmptyFile(File file) throws IOException {
        Writer o = new BufferedWriter(new FileWriter(file));
        o.write("");
        o.close();
    }

    protected void setUp() throws Exception {
        super.setUp();
        BasicConfigurator.configure();
        Logger.getRootLogger().setLevel(Level.DEBUG);
        
        freshdir.mkdirs();
        createEmptyFile(freshfile);
        
        olddir.mkdirs();
        createEmptyFile(oldfile);
        Calendar c = Calendar.getInstance();
        c.add(Calendar.DATE, -30);
        olddir.setLastModified(c.getTimeInMillis());
        oldfile.setLastModified(c.getTimeInMillis());

        String regex = "(?i).*\\.(file)";
        Pattern pattern = Pattern.compile(regex);
        runnable = new FileDeleter(new File[] { here }, 
                new LastModifiedAndFilenameFileFilter(Calendar.DATE, -30, pattern, DirectoryMode.DELETE_IF_EMPTY), 
                DeleteMode.DELETE);
    }

    protected void tearDown() throws Exception {
        super.tearDown();
    }

    public void testRun() {
        runnable.run();
        assertTrue(freshdir.exists());
        assertTrue(freshfile.exists());
        assertFalse(oldfile.exists());
        assertFalse(olddir.exists());
    }

}
