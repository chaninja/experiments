package org.coastal.util.file;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.Writer;

import static org.coastal.util.file.DirectoryHelper.DeleteMode.DELETE;
import static org.coastal.util.file.DirectoryHelper.DeleteMode.DELETE_ONLY_IF_EMPTY;

import org.apache.log4j.BasicConfigurator;
import org.apache.log4j.Level;
import org.apache.log4j.Logger;

import junit.framework.TestCase;


public class TestDirectoryHelper extends TestCase {
    private final File here = new File("./" + TestDirectoryHelper.class.getName());
    private final File freshdir = new File(here, "fresh");
    private final File freshfile = new File(freshdir, "do.not.delete.file");
    private final File emptydir = new File(here, "empty");

    private static void createEmptyFile(File file) throws IOException {
        Writer o = new BufferedWriter(new FileWriter(file));
        o.write("");
        o.close();
    }

    protected void setUp() throws Exception {
        super.setUp();
        BasicConfigurator.configure();
        Logger.getRootLogger().setLevel(Level.DEBUG);
        
        here.mkdirs();
        
        freshdir.mkdirs();
        createEmptyFile(freshfile);
        
        emptydir.mkdirs();
    }

    protected void tearDown() throws Exception {
        super.tearDown();
        DirectoryHelper.delete(here, DELETE);
    }

    public void testIsEmpty() {
        assertTrue(DirectoryHelper.isEmpty(emptydir));
        assertTrue(emptydir.list().length == 0);
        assertFalse(DirectoryHelper.isEmpty(freshdir));
        assertFalse(freshdir.list().length == 0);
    }

    public void testDelete() {
        assertTrue(DirectoryHelper.delete(emptydir, DELETE_ONLY_IF_EMPTY));
        assertFalse(emptydir.exists());
        
        assertFalse(DirectoryHelper.delete(freshdir, DELETE_ONLY_IF_EMPTY));
        assertTrue(freshdir.exists());
        
        assertTrue(DirectoryHelper.delete(freshdir, DELETE));
        assertFalse(freshdir.exists());
        
        assertTrue(DirectoryHelper.delete(here, DELETE));
        assertFalse(here.exists());
    }

}
