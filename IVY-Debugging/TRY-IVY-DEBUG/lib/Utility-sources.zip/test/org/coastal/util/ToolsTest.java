package org.coastal.util;

import junit.framework.TestCase;

public class ToolsTest extends TestCase {
	
	/**
	 * {@link Tools#ceil(double, double)} should return the smallest 
	 * (closest to negative infinity) value that is greater than or equal 
	 * to the argument and is equal to a mathematical integer.  
	 */
	public void testCeil() {
		//positive values
		assertEquals(1000d, Tools.ceil(990, 100));
		assertEquals(1300d, Tools.ceil(1234, 100));
		assertEquals(450d, Tools.ceil(449, 10));
		assertEquals(150d, Tools.ceil(150, 10));
		assertEquals(782d, Tools.ceil(782, 1));
		assertEquals(9900d, Tools.ceil(9876.54321, 100));

		//negative values
		assertEquals(-500d, Tools.ceil(-562.8237, 100));
		assertEquals(-150d, Tools.ceil(-150, 10));
		assertEquals(-150d, Tools.ceil(-150.0000000001, 10));
		assertEquals(-9800d, Tools.ceil(-9876.54321, 100));
		assertEquals(-782d, Tools.ceil(-782.27, 1));

		//positive values near 0
		assertEquals(10d, Tools.ceil(.00001, 10));
		assertEquals(1d, Tools.ceil(.0000001, 1));
		assertEquals(1d, Tools.ceil(Double.MIN_VALUE, 1));  //smallest positive non-zero
		
		//negative values near 0
		assertEquals(-0d, Tools.ceil(-.00001, 100000));
		assertEquals(-0d, Tools.ceil(-Double.MIN_VALUE, 1));  //largest negative non-zero
	}

}
