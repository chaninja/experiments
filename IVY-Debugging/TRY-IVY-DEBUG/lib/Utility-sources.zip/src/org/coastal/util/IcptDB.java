// $Id$
package org.coastal.util;

import java.sql.*;

/*
 * Created on Apr 9, 2004
 *
 * To change the template for this generated file go to
 * Window - Preferences - Java - Code Generation - Code and Comments
 */

/**
 * @author jbrothers
 *
 * To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Generation - Code and Comments
 */
public class IcptDB {
    public static IcptDB db = null;
    public boolean bUseHsql = false;

    Connection conn = null;
    private String db_file_name_prefix;

    public IcptDB(String db_file_name_prefix) throws Exception // note more general exception
    {
        this.db_file_name_prefix = db_file_name_prefix;
        createNewConnection(db_file_name_prefix);
    }

    public void createNewConnection(String db_file_name_prefix)  {
        try {
            Class.forName(bUseHsql ? "org.hsqldb.jdbcDriver" : "com.mysql.jdbc.Driver");
            if (bUseHsql) {
                conn = DriverManager.getConnection("jdbc:hsqldb:" + db_file_name_prefix, // filenames
                        "sa", // username
                        ""); // password
            } else {
                conn = DriverManager.getConnection("jdbc:mysql:" + db_file_name_prefix + "?autoReconnect=true", "root", "mysql");
            }

        } catch (Exception e) {
            e.printStackTrace();
            conn = null;
        }
    }

    public void shutdown() throws SQLException {

        conn.close(); // if there are no other open connection
        // db writes out to files and shuts down
        // this happens anyway at garbage collection
        // when program ends
    }

    //use for SQL commands DROP and INSERT and UPDATE
    public synchronized void update(String expression) throws SQLException {

        Statement st = null;

        try {
            st = conn.createStatement(); // statement objects can be reused with
            st.execute("SELECT 1");
        } catch (SQLException e) {
            //bad or stale connection object
            //create a new connection
            System.err.println("Connection object maybe stale");
            createNewConnection(this.db_file_name_prefix);
            //create statement again
            st = conn.createStatement();
        }

        int i = st.executeUpdate(expression); // run the query

        if (i == -1) {
            System.out.println("db error : " + expression);
        }

        st.close();
    } // void update()
    //  use for SQL commands DELETE

    public synchronized void execute(String expression) throws SQLException {

        try {
            Statement st = null;

            try {
                st = conn.createStatement(); // statement objects can be reused with
            } catch (Exception e) {
                //bad or stale connection object
                //create a new connection
                createNewConnection(this.db_file_name_prefix);
                //create statement again
                st = conn.createStatement();
            }
            st.executeUpdate(expression); // run the query

            st.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    //use for SQL commands CREATE and SELECT
    public synchronized void query(String expression) throws SQLException {

        Statement st = null;
        ResultSet rs = null;

        try {
            st = conn.createStatement(); // statement objects can be reused with
        } catch (Exception e) {
            //bad or stale connection object
            //create a new connection
            createNewConnection(this.db_file_name_prefix);
            //create statement again
            st = conn.createStatement();
        }
        // repeated calls to execute but we
        // choose to make a new one each time
        rs = st.executeQuery(expression); // run the query

        // do something with the result set.
        dump(rs);
        st.close(); // NOTE!! if you close a statement the associated ResultSet is
        // closed too
        // so you should copy the contents to some other object.
        // the result set is invalidated also  if you recycle an Statement
        // and try to execute some other query before the result set has been
        // completely examined.
    }

    public static void dump(ResultSet rs) throws SQLException {

        // the order of the rows in a cursor
        // are implementation dependent unless you use the SQL ORDER statement
        ResultSetMetaData meta = rs.getMetaData();
        int colmax = meta.getColumnCount();
        int i;
        Object o = null;

        // the result set is a cursor into the data.  You can only
        // point to one row at a time
        // assume we are pointing to BEFORE the first row
        // rs.next() points to next row and returns true
        // or false if there is no next row, which breaks the loop 
        for (; rs.next();) {
            for (i = 0; i < colmax; ++i) {
                o = rs.getObject(i + 1); // Is SQL the first column is indexed
                // with 1 not 0
                System.out.print(o.toString() + " ");
            }

            System.out.println(" ");
        }
    } //void dump( ResultSet rs )

    /**
     * @return Returns the conn.
     */
    public Connection getConn() {
        return conn;
    }

    public void getNewConnection() {
        createNewConnection(this.db_file_name_prefix);
    }
}
