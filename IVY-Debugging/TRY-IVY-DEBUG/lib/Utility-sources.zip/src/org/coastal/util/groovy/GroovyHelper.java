package org.coastal.util.groovy;

import groovy.lang.Binding;
import groovy.util.GroovyScriptEngine;
import groovy.util.ResourceException;
import groovy.util.ScriptException;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;

import org.apache.log4j.Logger;

/**
 * Utilities related to properties files.
 * 
 * @author chandra
 */
public class GroovyHelper {
	//===========================================================
	//    DECLARE
	//===========================================================
	
	protected static String grvPath = "./scripts";
	private static Logger log = Logger.getLogger(GroovyHelper.class);
	
	//===========================================================
	//    INIT
	//===========================================================

	//===========================================================
	//    MAIN
	//===========================================================
	public static void main(String[] args) {
		GroovyHelper rp = new GroovyHelper();
		rp.test2();
	}

	
	//===========================================================
	//    STATIC
	//===========================================================

	
	//===========================================================
	//    ACTION
	//===========================================================
	public static boolean updateSTRStation(String metarStationID, String stationType) {
		boolean result1 = false;
		try {
			Binding binding = new Binding();
			binding.setVariable("airportID", metarStationID);
			binding.setVariable("stationType", stationType);
			GroovyScriptEngine gse = new GroovyScriptEngine(grvPath);
			try {
				//result = (Boolean) 
				gse.run("UpdateSTRStation.groovy", binding);
				result1 = true;
			} catch (ResourceException rx) {
				log.error("updateSTRStation - Error: ", rx);
			} catch (ScriptException sx) {
				log.error("updateSTRStation - Error: ", sx);
			}
		} catch (Exception e) {
			log.error("updateSTRStation - Error: ", e);
		}
		return result1;
	}
	
	public static boolean updateStationConfig(String configFilePath, String stationID, 
											ArrayList<String> stationConfig, 
											String portID, ArrayList<String> serialConfig, 
											String operation) {
		boolean result1 = false;
		try {
			Binding binding = new Binding();
			binding.setVariable("operation", operation);
			binding.setVariable("stationSetupFile", configFilePath);
			binding.setVariable("stationID", stationID);
			binding.setVariable("portID", portID);
			binding.setVariable("stationConfig", stationConfig);
			binding.setVariable("serialConfig", serialConfig);
			
			File confDir = new File(configFilePath).getParentFile();
			String appHomePath = confDir.getParent();
			String scriptPath = new File(appHomePath, "scripts").getAbsolutePath();
			GroovyScriptEngine gse = new GroovyScriptEngine(scriptPath);
			try {
				//result = (Boolean) 
				gse.run("UpdateStationConfig.groovy", binding);
				result1 = true;
			} catch (ResourceException rx) {
				log.error("updateStationConfig - Error: ", rx);
			} catch (ScriptException sx) {
				log.error("updateStationConfig - Error: ", sx);
			}
		} catch (Exception e) {
			log.error("updateStationConfig - Error: ", e);
		}
		return result1;
	}
	
	
	public static boolean addMessageFormat(String msgFormatFilePath,
											String msgFormatName, String msgFormat) {
		boolean result1 = false;
		try {
			Binding binding = new Binding();
			binding.setVariable("msgFormatFile", msgFormatFilePath);
			binding.setVariable("msgFormatName", msgFormatName);
			binding.setVariable("msgFormat", msgFormat);

			File confDir = new File(msgFormatFilePath).getParentFile();
			String appHomePath = confDir.getParent();
			String scriptPath = new File(appHomePath, "scripts")
					.getAbsolutePath();
			GroovyScriptEngine gse = new GroovyScriptEngine(scriptPath);
			try {
				// result = (Boolean)
				gse.run("AddMessageFormat.groovy", binding);
				result1 = true;
			} catch (ResourceException rx) {
				log.error("addMessageFormat - Error: ", rx);
			} catch (ScriptException sx) {
				log.error("addMessageFormat - Error: ", sx);
			}
		} catch (Exception e) {
			log.error("addMessageFormat - Error: ", e);
		}
		return result1;
	}
	
	/**
	 * Read properties file, parse using regex, convert to HashMap.
	 */
	public static HashMap file2map() {
		HashMap _map = null;
		try {
			Binding binding = new Binding();
			binding.setVariable("fname", "vsp");
			GroovyScriptEngine gse = new GroovyScriptEngine(grvPath);
			try {
				gse.run("ParseProperties.groovy", binding);
				_map = (HashMap) binding.getVariable("map");
			} catch (ResourceException e) {
				e.printStackTrace();
			} catch (ScriptException e) {
				e.printStackTrace();
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
		return _map;
	}
	
	//===========================================================
	//    TEST
	//===========================================================
	public void test1() {
		setGrvPath("c:/groovy/scripts/");
		System.out.println("updateSTRStation = " + updateSTRStation("CYSC", "AWOS"));
	}

	public void test2() {
		setGrvPath("c:/groovy/scripts/");
		System.out.println("parseProperties-1 = " + file2map());
	}

	public static String getGrvPath() {
		return grvPath;
	}


	public static void setGrvPath(String grvPath) {
		GroovyHelper.grvPath = grvPath;
	}

	//===========================================================
	//    ACCESS
	//===========================================================
}
