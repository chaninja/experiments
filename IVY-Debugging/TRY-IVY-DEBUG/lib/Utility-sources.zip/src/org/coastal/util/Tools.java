// $Id: Tools.java 2433 2006-01-26 16:09:50Z mhart $
package org.coastal.util;

/**
 * This class contains various miscellaneous stand-alone tools used by multiple 
 * classes.
 * 
 * <p>Title: LinkedAbacus</p>
 * <p>Description: Test for running Aviation Intercept Algorithms</p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: Coastal Environmental Systems</p>
 * @author Michael Hart
 * @version 1.0
 */

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.Timestamp;
import java.text.DecimalFormat;
import java.text.FieldPosition;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.Properties;

import org.apache.log4j.BasicConfigurator;
import org.apache.log4j.PropertyConfigurator;

public class Tools {
  final String [] m_rgsMonthNames = { 
    "Jan", "Feb", "Mar", "Apr", "May", "Jun", 
    "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"
  };
  
  String m_sLogFileExtension = ".log"; 

  /**
   * Constructor.
   */
  public Tools() {
  }  // End of constructor.

	public enum Direction {
		NORTH, SOUTH, EAST, WEST;
	}
	
	public static class DMS {
		private final int degrees;
		private final int minutes;
		private final int seconds;
		private Direction direction;

		public int getDegrees() {
			return degrees;
		}

		public int getMinutes() {
			return minutes;
		}

		public int getSeconds() {
			return seconds;
		}
		
		public Direction getDirection() {
			return direction;
		}

		public DMS(int degrees, int minutes, int seconds) {
			this.degrees = degrees;
			this.minutes = minutes;
			this.seconds = seconds;
		}
		
		public DMS(int degrees, int minutes, int seconds, Direction direction) {
			this(degrees, minutes, seconds);
			this.setDirection(direction);
		}

		public void setDirection(Direction direction) {
			this.direction = direction;
		}

		/**
		 * Returns a <code>DMS</code> object holding the value of the specified <code>String</code>.  The
		 * string should have four parts, separated by spaces: degrees, minutes, seconds, direction.  Examples:
		 * <ul>
		 * <li> <tt>127 42 33 WEST</tt>
		 * <li> <tt>42 1 1 NORTH</tt>
		 * </ul>
		 * @throws NumberFormatException if the numeric portions of the string cannot be parsed as an integer
		 * @throws IllegalArgumentException if the direction portion of the string has
		 *         no <code>Tools.Direction</code> constant with the specified name
		 * @see Integer#valueOf(int)
		 * @see Enum#valueOf(Class, String)
		 * @see Tools.Direction
		 */
		public static DMS valueOf(String string) {
			String[] split = string.split(" ");
			int degrees = Integer.valueOf(split[0]);
			int minutes = Integer.valueOf(split[1]);
			int seconds = Integer.valueOf(split[2]);
			Direction dir = Direction.valueOf(split[3]);
			return new DMS(degrees, minutes, seconds, dir);
		}
		
		public String toString() {
			return String.format("%d %d %d %s", degrees, minutes, seconds, direction);
		}
	}
	
	public static DMS convertDecimalDegreesLatitudeToDMS(String latitude) {
		DMS latitudeDMS = convertDecimalDegreesToDMS(latitude);
		if(latitude.startsWith("-")) {
			latitudeDMS.setDirection(Direction.SOUTH);
		} else {
			latitudeDMS.setDirection(Direction.NORTH);
		}
		return latitudeDMS;
	}

	public static DMS convertDecimalDegreesLongitudeToDMS(String longitude) {
		DMS longitudeDMS = convertDecimalDegreesToDMS(longitude);
		if(longitude.startsWith("-")) {
			longitudeDMS.setDirection(Direction.WEST);
		} else {
			longitudeDMS.setDirection(Direction.EAST);
		}
		return longitudeDMS;
	}

	private static DMS convertDecimalDegreesToDMS(String value) {
		float latiVal = Float.parseFloat(value);
		//get the degrees.
		int degrees = (int) Math.abs(latiVal);
		float fractionalMins = (Math.abs(latiVal) - degrees) * 60;
		int mins = (int) fractionalMins;
		int secs = (int) ((fractionalMins - mins) * 60);
		return new DMS(degrees, mins, secs);
	}
	
	public static float convertDMSToDecimalDegrees(DMS dms) {
		//TODO why is this using float?
		float dd = dms.getDegrees() + (dms.getMinutes() / 60f) + (dms.getSeconds() / (60f * 60f));
		//		latilongiVal = (float) UTIL.roundDouble(latilongiVal, 5);  //TODO try figuring out why this "rounding" would have been necessary
		switch(dms.getDirection()) {
    		case WEST:
    		case SOUTH:
    			dd *= -1;
    			break;
    		default:
    			break;
		}

		return dd;
	}
  
  /**
   * This method converts the inputted double value into a formatted string.
   * @param sFormat format definition
   * @param dValue value to be converted
   * @return formatted string.
   */
  public String formatValue(String sFormat, double dValue) {
    DecimalFormat fmt    = new DecimalFormat (sFormat);
    StringBuffer  buffer = new StringBuffer ();
    FieldPosition pos    = new FieldPosition (0);

    buffer.setLength(0);
    fmt.format (dValue, buffer, pos);
    return buffer.toString();
  }  // End of method formatValue

  /**
   * Method round allows the input value dValue to be rounded to the nearest
   * value specified by input dRoundTo and returns the result as a double.
   * @param dValue value to round
   * @param dRoundTo value to round dValue to the nearest.
   * @return rounded value.
   */
  public double round(double dValue, double dRoundTo) {
    if(dRoundTo == 0.0) {
      return (double) Math.round(dValue);
    }  // End of if statement.
    else {
      return ((double) Math.round(dValue/dRoundTo))*dRoundTo;
    }  // End of else statement.
  }  // End of method round
  
  public static double ceil(double value, double roundTo) {
	  if(roundTo == 0d) {
		  roundTo = 1d;
	  }
	  
	  return Math.ceil(value/roundTo)*roundTo;
  }

  /**
   * Method floor allows the input value dValue to be rounded down to the nearest
   * value specified by input dRoundTo and returns the result as a double.
   * @param dValue value to round down.
   * @param dRoundTo value to round dValue to the nearest.
   * @return rounded down value.
   */
  public double floor(double dValue, double dRoundTo) {
    if(dRoundTo == 0.0) {
      return (double) Math.floor(dValue);
    }  // End of if statement.
    else {
      return ((double) Math.floor(dValue/dRoundTo))*dRoundTo;
    }  // End of else statement.
  }  // End of method round

  /**
   * This method returns the current system time in seconds since epoch.
   * @return current time in seconds.
   */
  public int systemTime() {
    // Convert value in milliseconds to seconds.
    double  dTime       = ((double) systemTimeInMilliseconds())/1000.0;
    Double  doubleTime  = new Double(Math.round(dTime));

    return doubleTime.intValue();
  }  // End of method systemTime

  public long systemTimeInMilliseconds() {
    Date    dateCurrent = new Date();
    return dateCurrent.getTime();
  }  // End of method systemTimeInMilliseconds

  public String createDataFileName() {
    GregorianCalendar gc = new GregorianCalendar();

    return "log " + gc.get(Calendar.YEAR) + " " +
      m_rgsMonthNames[gc.get(Calendar.MONTH)] + " " +
      formatValue("00", (double) gc.get(Calendar.DAY_OF_MONTH)) + " @ " +
      formatValue("00", (double) gc.get(Calendar.HOUR_OF_DAY)) +
      formatValue("00", (double) gc.get(Calendar.MINUTE)) + m_sLogFileExtension;
  }  // End of method createDataFileName


  public String createUTCDataFileName() {
    SystemTimestamp sts = new SystemTimestamp(systemTime());

    return "log " + sts.getUTCValue(sts.YEAR) + " " +
      m_rgsMonthNames[sts.getUTCValue(sts.MONTH) - 1] + " " +
      formatValue("00", (double) sts.getUTCValue(sts.DAY)) + " @ " +
      formatValue("00", (double) sts.getUTCValue(sts.HOUR)) +
      formatValue("00", (double) sts.getUTCValue(sts.MINUTE)) + " UTC" + 
      m_sLogFileExtension;
  }  // End of method createUTCDataFileName

  public String createShortUTCDataFileName(String sAdditionalName,
      boolean bMidnightFlag) {
    return createShortUTCDataFileName(sAdditionalName, 
      systemTime(), bMidnightFlag);
  }  // End of method createShortUTCDataFileName

  public String createShortUTCDataFileName(String sAdditionalName,
	      int nTime, boolean bMidnightFlag) {
    SystemTimestamp sts = new SystemTimestamp(nTime);

    String sFileName = 
      formatValue("00", (double) (sts.getUTCValue(sts.YEAR) % 100)) +
      formatValue("00", sts.getUTCValue(sts.MONTH))                 +
      formatValue("00", (double) sts.getUTCValue(sts.DAY))          +
      formatValue("00", bMidnightFlag ? 0.0 : 
        (double) sts.getUTCValue(sts.HOUR));
    if(sAdditionalName != null) {
      if(sAdditionalName.length() > 0) {
        sFileName += "_" + sAdditionalName;
      }  // End of if statement.
    }  // End of if statement.

    return sFileName + m_sLogFileExtension;
  }  // End of method createShortUTCDataFileName

  public String createDateOnlyUTCDataFileName() {
    SystemTimestamp sts = new SystemTimestamp(systemTime());

    return "log " + sts.getUTCValue(sts.YEAR) + " " +
      m_rgsMonthNames[sts.getUTCValue(sts.MONTH) - 1] + " " +
      formatValue("00", (double) sts.getUTCValue(sts.DAY)) + " UTC" + 
      m_sLogFileExtension;
  }  // End of method createDateOnlyUTCDataFileName

  /**
   * This method makes any non-printable ASCII characters contained
   * within the inputted string viewable by converting them to their
   * ASCII-equivalent codes and enclosing them within brackets "<" and
   * ">".  This is the same form as is used in ZENOSOFT.
   * @param sMessage inputted message to reveal hidden characters.
   * @return new message with revealed hidded characters.
   */
  public String showHiddenCharacters(String sMessage) {
    String sRevealed = "";

    if(sMessage == null ? false : sMessage.length() > 0) {
      for(int i = 0; i < sMessage.length(); i++) {
        String sCharacter = sMessage.substring(i, i + 1);
        if(sCharacter.matches("([\\p{Graph}])")) {
          sRevealed      += sCharacter;
        }  // End of if statement.
        else {
          byte [] rgbytes = sCharacter.getBytes();
          sRevealed      += 
            ("<" + Integer.toHexString(rgbytes[0] & 0xff).toUpperCase() + ">");
        }  // End of else statement.
      }  // End of for loop.
    }  // End of if statement.

    return sRevealed;
  }  // End of method showHiddenCharacters

  public String timeInUTCSecondsToString(int nSeconds) {
    String    sTime = "";
    Timestamp ts    = new Timestamp(((long) nSeconds) * 1000);

    sTime = ts.toString();
    if(sTime.length() > 19) {
      sTime = sTime.substring(0, 19);
    }  // End of if statement.
    // sTime = sTime.replace('-', '/');

    return sTime;
  }  // End of method timeInUTCSecondsToString

  /**
   * This method returns the substring contained within the source String
   * between the specified starting and ending Strings if and only if all
   * of the inputted String objects exist and the starting and ending String
   * objects are found within the source String object.
   * @param sSource source String to locate substring in
   * @param sStart the String that represents where the desired substring 
   * immediately begins thereafter
   * @param sEnd the String that represents where the desired substring ends 
   * and does not include
   * @return substring as a String object upon success or a null String object
   * upon failure.
   */
  public String substringBetweenStrings(String sSource, String sStart,
      String sEnd) {
    String sResult  = null;
    String sPartial = substringAfterString(sSource, sStart);

    if(sPartial != null) {
      try {
        int nIndex = sPartial.indexOf(sEnd);
        if(nIndex >= 0) {
          sResult  = sPartial.substring(0, nIndex);
        }  // End of if statement.
      }  // End of try statement.
      catch (Exception e) {
        sResult = null;
      } // End of catch statement.
    }  // End of if statement.

    return sResult;
  }  // End of method substringBetweenStrings

  /**
   * This method returns a substring from a source String object that follows
   * the starting String object that it should immedately follow as long as the
   * both source and starting String objects exist and the starting String
   * object is found within the source String object.
   * @param sSource source String object
   * @param sStart starting String object
   * @return substring as a String object upon success or a null pointer upon
   * failure.
   */
  public String substringAfterString(String sSource, String sStart) {
    String sResult = null;

    if(sSource != null && sStart != null) {
      try {
        int nIndex = sSource.indexOf(sStart);
        if(nIndex >= 0) {
          sResult = sSource.substring(nIndex + 1, sSource.length());
        }  // End of if statement.
      }  // End of try statement.
      catch (Exception e) {
        sResult = null;
      } // End of catch statement.
    }  // End of if statement.

    return sResult;
  }  // End of method substringAfterString
  
  
  public static Properties loadProperties(String niPropsFile)
		throws IOException, FileNotFoundException {
	Properties niProps = new Properties();
	niProps.load(new FileInputStream(niPropsFile));
	return niProps;
}

/**
   * Initializes Log4j with the given properties file.
   * @see {@link PropertyConfigurator#configureAndWatch(String)}
   * @param propFile the log4j properties file
   */
  public static void setUpLogging(File propFile){
	  // Set up logging configuration. log4j logging is for debugging purpose.
	  BasicConfigurator.configure();
	  PropertyConfigurator.configureAndWatch(propFile.getAbsolutePath());
  }

	public Double doubleValue(String property) {
		Double value = null;
		try {
			value = Double.parseDouble(property);
		} catch (NumberFormatException e) {
		}
		return value;
	}  
}  // End of class Tools
