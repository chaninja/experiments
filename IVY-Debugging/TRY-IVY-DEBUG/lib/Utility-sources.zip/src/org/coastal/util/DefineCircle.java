package org.coastal.util;

/**
 * Class DefineCircle allows for the definition of three values necessary to
 * define a circle for graphing purposes:  the center point (x & y) and its 
 * radius.
 * 
 * <p>Title: LinkedAbacus</p>
 * <p>Description: Test for running Aviation Intercept Algorithms</p>
 * <p>Copyright: Copyright (c) 2003 - 2004</p>
 * <p>Company: Coastal Environmental Systems</p>
 * @author Michael Hart
 * @version 1.0
 */

public class DefineCircle {
  int m_nXCenter;
  int m_nYCenter;
  int m_nRadius;

  public DefineCircle(int nXCenter, int nYCenter, int nRadius) {
    m_nXCenter = nXCenter;
    m_nYCenter = nYCenter;
    m_nRadius  = nRadius;
  }  // End of constructor

  public int getXCenter() {
    return m_nXCenter;
  }  // End of getXCenter

  public int getYCenter() {
    return m_nYCenter;
  }  // End of getXCenter

  public int getRadius() {
    return m_nRadius;
  }  // End of getXCenter
}  // End of class DefineCircle
