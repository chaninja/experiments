/**
 * Derived from Examples of Hack #32, Swing Hacks by Joshua Marinacci & Chris Adamson. Copyright 2005 O'Reilly & Associates
 * http://www.oreilly.com/pub/a/oreilly/ask_tim/2001/codepolicy.html 
 */
package org.coastal.util.swing;
import java.io.*;
import java.util.*;
import java.util.zip.*;

public class ZipFileProxy extends DebugFile {
	private static final long serialVersionUID = 5274890793019549787L;
	protected Map<String, Map<String, String>> hash;
    private ZipFile zipfile;
    private File real_file;
    
    public ZipFileProxy(File file) {
        super(file.getAbsolutePath());
        try {
            this.hash = new HashMap<String, Map<String, String>>();
            this.real_file = file;
            zipfile = new ZipFile(file,ZipFile.OPEN_READ);
            hash.put("", new HashMap<String, String>());
            Enumeration en = zipfile.entries();
            parse(en);
        } catch (IOException ex) {
            System.out.println(ex.getMessage());
            ex.printStackTrace();
        }
    }
    
    
    public String getPath() { return real_file.getPath(); }
    public boolean exists() { return real_file.exists(); }
    public String getName() { return real_file.getName(); }
    
    /* create a hashtable of the entries and their paths */
    private void parse(Enumeration en) {
        while(en.hasMoreElements()) {
            ZipEntry ze = (ZipEntry)en.nextElement();
            String full_name = ze.getName();
            String name = full_name;
            if(ze.isDirectory()) {
                name = full_name.substring(0,full_name.length()-1);
            }

            int brk = name.lastIndexOf("/");

            String parent = "";
            if(brk != -1) {
                parent = name.substring(0,brk+1);
            }

            if(ze.isDirectory()) {
                HashMap<String, String> children = new HashMap<String, String>();
                hash.put(full_name,children);
            }
            
            hash.get(parent).put(full_name,"");
        }
    }
    
    public File[] getFiles(String dir) {
        Map children = hash.get(dir);
        File[] files = new File[children.size()];
        Iterator it = children.keySet().iterator();
        int count = 0;
        while(it.hasNext()) {
            String name = (String)it.next();
            files[count] = new ZipEntryFileProxy(this, zipfile, name, this);
            count++;
        }
        return files;
    }    
}

