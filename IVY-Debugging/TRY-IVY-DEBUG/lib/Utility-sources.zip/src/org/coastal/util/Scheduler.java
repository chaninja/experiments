// $Id: Scheduler.java 1938 2005-11-03 23:22:52Z mhart $
package org.coastal.util;

import java.util.ArrayList;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.TimeUnit;

import org.apache.log4j.Logger;

/**
 * 
 * <p>Scheduler.java
 * 
 * <p>written by Marc Singer 19 Sep 2003 
 * <p>modified by Michael Hart
 * 
 * <p>Copyright (C) 2003 The Buici Company
 * 
 * <p>Scheduler for regularized invocations.
 */
public class Scheduler extends Thread {
	private static Logger log = Logger.getLogger(Scheduler.class);
	SortedLinkedList m_sll        = new SortedLinkedList();
    boolean          m_fInactive  = false;
    TaskQueue        m_taskqueue  = null;
    boolean          m_bPrint     = false;
    ArrayList        m_alKillList = new ArrayList();
	LinkedBlockingQueue<ScheduledEvent> m_qTopoftheMinuteEvents = new LinkedBlockingQueue<ScheduledEvent>();

    public Scheduler () { 
      start ();
    }  // Start thread, wait till there's
       // something to do

    public Scheduler (TaskQueue taskqueue) { 
      m_taskqueue = taskqueue;
      setupTopOftheMinuteEventScheduler();
      start ();
    }  // Start thread, wait till there's
	// something to do

    private void setupTopOftheMinuteEventScheduler() {
    	ExecutorService executor =  Executors.newSingleThreadExecutor();
		executor.execute(new Runnable(){
			public void run(){
				scheuleTopoftheMinuteEvents();
			}
		}); 
		executor.shutdown();;
    }
    
    /**
     * Read events from the queue and insert them into the scheduler 
     * when the time is  top of the minute, which is minute 0.
     */
    protected void scheuleTopoftheMinuteEvents() {
    	Object qObj = null;
    	try {
    		//wait till the top of the next minute.
			int currSec = new SystemTimestamp().getSec();
			if( currSec > 5)
				Thread.sleep((60 - currSec) * 1000);
    		
			while( (qObj = m_qTopoftheMinuteEvents.poll(180, TimeUnit.SECONDS)) != null){
				ScheduledEvent ev = (ScheduledEvent) qObj;
				m_sll.insert(ev);
				log.debug("Scheduler : insert : inserted at index "
						+ m_sll.lastInsertionIndex() + ", size = "
						+ m_sll.size() + ", at " + new SystemTimestamp((int)ev.event_time() / 1000).toTimeString());
			}
		} catch (InterruptedException e) {
			
		}
	}
	public synchronized void finalize () {
		m_fInactive = true;
		notify ();
    }

    public synchronized void run() {
    	this.setName("Scheduler");
		while (!m_fInactive) {
			long msTarget = 0;
			long msNow = System.currentTimeMillis();
			if (m_bPrint) {
				log.info("Scheduler : run : awake at " + msNow / 1000.0);
			} // End of if statement.
			try {
				// Carry out any scheduled events whose timestamps have
				// expired.
				while (((ScheduledEvent) m_sll.top()).event_time() <= msNow) {
					ScheduledEvent ev = (ScheduledEvent) m_sll.popTop();
					// 11/3/2005 MJH : Only proceed if the event was not killed.
					if (m_alKillList.size() > 0) {
						String sIdentity = ev.identity();
						if (sIdentity.length() > 0) {
							if (m_alKillList.contains(sIdentity)) {
								ev.kill();
								m_alKillList.remove(m_alKillList
										.indexOf(sIdentity));
							} // End of if statement.
						} // End of if statement.
					} // End of if statement.
					if (!ev.isKilled()) {
						if (m_bPrint) {
							log.info("Scheduler : popTop : size = "
									+ m_sll.size() + ", time = "
									+ ev.event_time() / 1000);
						} // End of if statement.
						if (m_taskqueue != null) {
							m_taskqueue.insert(ev.runnable());
						} // End of if statement.
						else {
							ev.runnable().run();
						} // End of else statement.
						ev.calc();
						if (ev.event_time() > 0) {
							m_sll.insert(ev);
							if (m_bPrint) {
								System.out
										.println("Scheduler : run : inserted at index "
												+ m_sll.lastInsertionIndex()
												+ ", size = "
												+ m_sll.size()
												+ ", at "
												+ +ev.event_time()
												/ 1000);
							} // End of if statement.
						} // End of if statement.
					} // End of if statement.
				} // End of while loop.
				msTarget = ((ScheduledEvent) m_sll.top()).event_time();
			} // End of try statement.
			catch (Exception ex) {
				// Ensure that any possible exception is caught.
//				msTarget = msNow + 1000 * 60; // 60 second default
				//changed to 1 second wait. Chandra 
				msTarget = msNow + 1000 * 1; // 1 second default
				if (m_bPrint) {
					log.info(ex.getMessage()
							+ " : Scheduler : run : " + ex.getStackTrace());
				} // End of if statement.
			} // End of catch statement.

			long msWait = msTarget - System.currentTimeMillis();
			// Only sleep if there is actually a positive difference.
			if (msWait > 0) {
				try {
					if (m_bPrint) {
						log.info("Scheduler : run: sleeping "
								+ msWait);
					} // End of if statement.
					wait(msWait);
				} // End of try statement.
				catch (InterruptedException ex) {
					if (m_bPrint) {
						System.out
								.println("InterruptedException: Scheduler : run");
					} // End of if statement.
				} // End of catch statement.
			} // End of if statement.
		} // End of while loop.
	}  // End of method run

    public synchronized void insert(ScheduledEvent ev) {
		// An exception is highly unlikely to occur here, but the "try-catch"
		// block is used to ensure reliabitlity.
		try {
			m_sll.insert(ev);
			if (m_bPrint) {
				log.debug("Scheduler : insert : inserted at index "
						+ m_sll.lastInsertionIndex() + ", size = "
						+ m_sll.size() + ", at " + +ev.event_time() / 1000);
			} // End of if statement.
		} // End of try statement.
		catch (Exception e) {
			if (m_bPrint) {
				log.warn(e.getMessage() + " : Scheduler : insert");
			} // End of if statement.
		} // End of catch statement.
		notify(); // Wake-up thread
	}  // End of method insert

    public synchronized void insert(ScheduledEvent ev, boolean topOfTheMinute) {
		// An exception is highly unlikely to occur here, but the "try-catch"
		// block is used to ensure reliabitlity.
		try {
			if (topOfTheMinute){
				//add the event to a queue for scheduling later at the top of the minute.
				m_qTopoftheMinuteEvents.offer(ev);
			}
			else {
				m_sll.insert(ev);
				log.debug("Scheduler : insert : inserted at index "
						+ m_sll.lastInsertionIndex() + ", size = "
						+ m_sll.size() + ", at " + new SystemTimestamp((int)ev.event_time() / 1000).toTimeString());
			}
		} 
		catch (Exception e) {
			if (m_bPrint) {
				log.warn(e.getMessage() + " : Scheduler : insert");
			} 
		}
		notify(); // Wake-up thread
	} 
    
    public void kill(String sIdentity) {
      if(sIdentity != null) {
        m_alKillList.add(sIdentity);
      }  // End of if statement.
    }  // End of method kill

    public void setPrintDiag(boolean bPrint) {
      m_bPrint = bPrint;
    }  // End of method setPrintDiag
}  // End of class Scheduler
