package org.coastal.util;

/**
 * <p>Title: LinkedAbacus</p>
 * <p>Description: Test for running Aviation Intercept Algorithms</p>
 * <p>Copyright: Copyright (c) 2003 - 2004</p>
 * <p>Company: Coastal Environmental Systems</p>
 * @author Michael Hart
 * @version 1.0
 */

public class ConvertTemperature extends ConvertUnits {
  final public int CELSIUS         = 0;
  final public int FAHRENHEIT      = 1;
  final public int KELVIN          = 2;
  final public int RANKINE         = 3;
  final String []  m_rgsUnitsNames = { "degC", "degF", "degK", "degR" };

  public int numberOfUnitNames() {
    return m_rgsUnitsNames.length;
  }  // End of method numberOfUnitNames

  public String unitName(int nIndex) {
    String sName = "";
    if(nIndex >= 0 && nIndex < numberOfUnitNames()) {
      sName = m_rgsUnitsNames[nIndex];
    }  // End of if statement.
    return sName;
  }  // End of method unitName

  public double convert(double dTemperature, int nOldUnitsID, int nNewUnitsID) {
    double dConverted = dTemperature;

    // Convert temperature to Celsius
    switch(nOldUnitsID) {
      case FAHRENHEIT: {
        dConverted  = toCelsius(dConverted);
        break;
      }  // End of case statement.
      case KELVIN: {
        dConverted -= 273.15;
        break;
      }  // End of case statement.
      case RANKINE: {
        dConverted  = toCelsius(dConverted - 460.0);
        break;
      }  // End of case statement.
    }  // End of switch statement.
    // Convert to Celsius to new units
    switch(nNewUnitsID) {
      case FAHRENHEIT: {
        dConverted  = toFahrenheit(dConverted);
        break;
      }  // End of case statement.
      case KELVIN: {
        dConverted += 273.15;
        break;
      }  // End of case statement.
      case RANKINE: {
        dConverted  = toFahrenheit(dConverted) + 460.0;
        break;
      }  // End of case statement.
    }  // End of switch statement.

    return dConverted;
  }  // End of method convert

  private double toCelsius(double dTemperature) {
    return (dTemperature - 32.0)*(5.0/9.0);
  }  // End of method toCelsius

  private double toFahrenheit(double dTemperature) {
    return (9.0/5.0)*dTemperature + 32.0;
  }  // End of method toFahrenheit
}  // End of class ConvertTemperature
