package org.coastal.util;

/**
 * <p>Title: TamosAbacus</p>
 * <p>Description: TAMOS Algorithms</p>
 * <p>Copyright: Copyright (c) 2005</p>
 * <p>Company: Coastal Environmental Systems</p>
 * @author Michael Hart
 * @version 1.0
 */

public class ConvertSpeed extends ConvertUnits {
  public final int KNOTS                   = 0;
  public final int KILOMETERS_PER_HOUR     = 1;
  public final int KILOMETERS_PER_HOUR_KPH = 2;
  public final int MILES_PER_HOUR          = 3;
  public final int METERS_PER_SECOND       = 4;
  final String []  m_rgsUnitsNames         = {
    "kts", "km/h", "kph", "mph", "m/s"
  };

  public double convert(double dSpeed, int nOldUnitsID, int nNewUnitsID) {
    double dConverted = dSpeed;

    // Convert initially into meters/second
    switch(nOldUnitsID) {
      case KNOTS: {
        dConverted *= 0.51444444;
        break;
      }  // End of case statement.

      case KILOMETERS_PER_HOUR:
      case KILOMETERS_PER_HOUR_KPH: {
        dConverted /= 3.6;
        break;
      }  // End of case statement.

      case MILES_PER_HOUR: {
        dConverted *= 0.44704;
        break;
      }  // End of case statement.
    }  // End of switch statement.

    // Convert meters/second into new units.
    switch(nNewUnitsID) {
      case KNOTS: {
        dConverted /= 0.51444444;
        break;
      }  // End of case statement.

      case KILOMETERS_PER_HOUR:
      case KILOMETERS_PER_HOUR_KPH: {
        dConverted *= 3.6;
        break;
      }  // End of case statement.

      case MILES_PER_HOUR: {
        dConverted /= 0.44704;
        break;
      }  // End of case statement.
    }  // End of switch statement.

    return dConverted;
  }  // End of method convert

  public int numberOfUnitNames() {
    return m_rgsUnitsNames.length;
  }  // End of method numberOfUnitNames

  public String unitName(int nIndex) {
    String sName = "";
    if(nIndex >= 0 && nIndex < numberOfUnitNames()) {
      sName = m_rgsUnitsNames[nIndex];
    }  // End of if statement.
    return sName;
  }  // End of method unitName
}  // End of class ConvertSpeed
