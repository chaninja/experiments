package org.coastal.util;


import java.net.URL;
import java.text.DecimalFormat;
import java.text.NumberFormat;

import javax.swing.ImageIcon;

/**
 * @author rboyd
 *
 */
public class UTIL {
    private static final String LOG_DIR = "logs";

    public static void main(String[] args) {
    }

    public static String currentDirectory() {
        String currentPath = System.getProperty("user.dir");
//        String[] split = currentPath.split(":");
//        return split[0];
        return currentPath;
    }
    
    public static String currentDirectoryforCharts() {
        String currentPath = System.getProperty("user.dir");
        String[] split = currentPath.split(":");
        return split[0];
    }
    
    public static String currentPath() {
        String currentPath = System.getProperty("user.dir");
        return currentPath;
    }

    /**
     * Returns the current log directory
     * @return String
     */
    public static String logDirectory() {
        return LOG_DIR;
    }
    
    public static boolean isInside(long num1, long num2, long tolerance) {
        long _min = num2 - tolerance;
        long _max = num2 + tolerance;
        return (num1 >= _min) && (num1 <= _max);
    }

    public static boolean isInside(Long num1, Long num2, Long tolerance) {
        long _num1 = num1.longValue();
        long _num2 = num2.longValue();
        long _tolerance = tolerance.longValue();
        return UTIL.isInside(_num1, _num2, _tolerance);
    }

    public static String formatValue(String sValue, String sPrec) {
        String localValue = "";
        if (null != sValue)
            localValue = sValue;
        if (null != sPrec) {
            if (!"".equals(sPrec))
                try {
                    NumberFormat formatter = new DecimalFormat(sPrec);
                    localValue = formatter.format(Double.valueOf(localValue));
                } catch (NumberFormatException e) {
                    e.printStackTrace();
                }
        }
        return localValue;
    }
    
    public static String getResourcePath() {
        return "intercept/resource/property/";
    }
    
    public static final double roundDouble(double d, int places) {
		return Math.round(d * Math.pow(10, (double) places)) / Math.pow(10, (double) places);
	}
    
    public static ImageIcon getImageIcon(String imageName){
    	URL url = UTIL.class.getClassLoader().getResource(imageName);
//		log.info("url =" + url.getPath());
		return new ImageIcon(url);
    }
    
    /**
	 * <p>Convert the numeric string to its binary form and pad with zeros to the appropriate number of bits.</p>
	 * @param rawData
	 * @param padToSize
	 * @return String
	 */
	public static String numberToBinaryString(String rawData, int padToSize) throws Exception {
		String inBinary = "";
		try {
			if (rawData.indexOf(".0") != -1) { //If precision doesn't matter, use this
				inBinary = Integer.toBinaryString(Integer.parseInt(rawData.substring(0,rawData.indexOf("."))));
			} else { //If just an int, use this.
				inBinary = Integer.toBinaryString(Integer.parseInt(rawData));
			}
		} catch (NumberFormatException nfe) {
			try { //Number is a Double with meaningful precision, so use it -- may mean more bits than we are supposed to have
				inBinary = Long.toBinaryString(Double.doubleToRawLongBits(Double.parseDouble(rawData)));
			} catch (Exception e) {
				//If rawData isn't a number, then make the value a missing number
				inBinary = setToMissing(padToSize).toString();
			}
		}
		
		try {
			for (int i = 0; inBinary.length() < padToSize; i++)  {
				inBinary = "0"+inBinary;
			}
			/*
			if (inBinary.length() > padToSize) {
				logger.info("NCPMessageBuilder::numberToBinaryString() -- "+rawData+" == "+inBinary+" should have "+padToSize+" bits but has " + inBinary.length() ,"NCPMessageBuilder.class");
			}*/
		} catch (Exception e) {
			throw e;
		}
		return inBinary;
	}
	/**
	 * <p>Create a StringBuffer the size of the received int with all bits set. </p>
	 * @param pad
	 * @return StringBuffer
	 */
	private static StringBuffer setToMissing(int pad) {
		StringBuffer value = new StringBuffer();
		for (int i =0; i < pad; i++) {
			value = value.append("1");
		}
		return value;
	}

	/**
	 * <p>Convert a string of ascii text to its binary form and pad with zeros to the appropriate number of bits.</p>
	 * @param rawData
	 * @param padSize
	 * @return
	 */
	public static String asciiToBinaryString(String rawData, int padSize) {
		String value = new String();
		try {
			byte[] b = rawData.getBytes("US-ASCII");
 
	        for(int i = 0; i < rawData.length(); i++) {
	        	String temp = (Integer.toBinaryString(b[i]));
	        	temp = padToSize(8, temp);
	            value += temp;
	        }    
		} catch (java.io.UnsupportedEncodingException uce) {			
		}
	
		value = padToSize(padSize, value);
		return value;
		
	}
	
	/**
	 * @param padToSize
	 * @param value
	 * @return
	 */
	private static String padToSize(int padToSize, String value) {
		for (int i = 0; value.length() < padToSize; i++)  {
			value = "0"+value;
		}
		return value;
	}
}
