package org.coastal.util;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.StringReader;
import java.util.Properties;
import java.util.TreeSet;

public class PropertiesHelper {

	private static final String ENCODING = "8859_1";
	private static final String COMMENTS = Properties.class.getName() + " sorted by " + PropertiesHelper.class.getName() + ".";
	
	/**
	 * Writes Properties to an OutputStream in sorted order.  
	 * @param p a Properties.
     * @param out an output stream.
     * @param comments a description of the property list.
	 * @throws IOException
	 */
	public static void writeSorted(final Properties p, final OutputStream out, final String comments) throws IOException {
		String allComments = COMMENTS;
		if(comments != null) {
			StringBuilder allCommentsBuff = new StringBuilder(COMMENTS);
			allCommentsBuff.append("  Original comments: ");
			allCommentsBuff.append(comments);
			allComments = allCommentsBuff.toString();
		}
		
		ByteArrayOutputStream os = new ByteArrayOutputStream();
		p.store(os, allComments);
		String propsAsString = os.toString(ENCODING);
		BufferedReader reader = new BufferedReader(new StringReader(propsAsString));

		TreeSet<String> ts = new TreeSet<String>();
		
		String line;
		while((line = reader.readLine()) != null) {
			ts.add(line);
		}

		BufferedWriter awriter = new BufferedWriter(new OutputStreamWriter(out, ENCODING));
        for (String string : ts) {
        	writeln(awriter, string);
        }
        awriter.flush();
	}

	private static void writeln(BufferedWriter bw, String s) throws IOException {
        bw.write(s);
        bw.newLine();
	}
}
