package org.coastal.util.file;

import java.io.File;
import java.io.FileFilter;


public class DirectoryFileFilter implements FileFilter {
    private final static DirectoryFileFilter INSTANCE = new DirectoryFileFilter();
    
    private DirectoryFileFilter() {}
    
    public static DirectoryFileFilter getInstance() {
        return INSTANCE;
    }
    
    public boolean accept(File file) {
        return file != null && file.isDirectory();
    }
}
