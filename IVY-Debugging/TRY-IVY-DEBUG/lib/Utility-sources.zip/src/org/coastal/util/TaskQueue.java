// $Id: TaskQueue.java 2443 2006-01-30 16:59:45Z mhart $
package org.coastal.util;

/* TaskQueue.java

   written by Marc Singer
   20 Sep 2003
   comments expanded upon TaskQueue by Michael Hart

   Modified to introduce thread pooling.
   Copyright (C) 2003 The Buici Company

   -----------
   DESCRIPTION
   -----------

   Implementation of a work queue with a single execution thread to
   serialize task execution.

   MJH:
   Class TaskQueue executes runnable threads that have been inserted into its
   internal LinkedList, which is acting as a last-in/first-out stack.  The task
   does nothing when its LinkedList queue is empty, but is notified whenever
   a runnable class has been inserted.
   
   Modified to use java thread pooling to use multiple threads for executing tasks.
   Chandra Srinivasan
*/

import java.util.LinkedList;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class TaskQueue extends Thread {

    private static final int POOL_THREAD_SIZE = 10;
	LinkedList m_queue = new LinkedList ();
    boolean m_fInactive = false;
    ExecutorService executor = null;
    
    public void run() {
		while (!m_fInactive) {
			try {
				Runnable runnable = remove();
				this.setName(runnable.getClass().getName());
				executor.submit(runnable);
			} catch (Exception ex) {
				ex.printStackTrace();
			}
		}
	}

    public void runOld() {
		while (!m_fInactive) {
			try {
				Runnable runnable = remove();
				this.setName(runnable.getClass().getName());
				yield(); // Just to be nice; probably unnecessary
				runnable.run();
			} catch (Exception ex) {
				ex.printStackTrace();
			}
		}
	}
    
    public TaskQueue () {
      // log.info("TaskQueue : " + toString());  
      setDaemon (true);
      executor = Executors.newFixedThreadPool(POOL_THREAD_SIZE); //create a 10 pool thread.
      start ();
    }  // End of constructor method

    public synchronized void insert (Runnable runnable) {
	m_queue.addLast (runnable); 
	notify (); 
    }

    public synchronized void finalize () {
		m_fInactive = true;
    }

    synchronized Runnable remove () throws InterruptedException {
	while (m_queue.isEmpty ()) {
	    try {
		wait ();
	    } catch (InterruptedException ex) { }
	}
	return (Runnable) m_queue.removeFirst (); 
    }
}  // End of class TaskQueue
