package org.coastal.util;


/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: Coastal Environmental Systems</p>
 * @author Michael Hart
 * @version 1.0
 */

import java.text.DateFormat;
import java.text.DecimalFormat;
import java.text.FieldPosition;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.Locale;
import java.util.StringTokenizer;
import java.util.TimeZone;

public class SystemTimestamp {
  private Date      m_date;
  private String    m_sLocalDate = "";
  private String    m_sUTCDate   = "";
  private ArrayList m_alLocal = new ArrayList();
  private ArrayList m_alUTC   = new ArrayList();
  public final int  WEEKDAY   = 0;
  public final int  MONTH     = 1;
  public final int  DAY       = 2;
  public final int  YEAR      = 3;
  public final int  HOUR      = 4;
  public final int  MINUTE    = 5;
  public final int  SECOND    = 6;

  /**
   * This constructor sets the current Timestamp values to the current system
   * time.
   */
  public SystemTimestamp() {
    Tools tools = new Tools();
    setup(tools.systemTime());
  }  // End of constructor.

  /**
   * This constructor expects a time in seconds, not milliseconds, and sets
   * the Timestamp values to the inputted time in seconds since epoch.
   * @param nSeconds time in seconds since epoch.
   */
  public SystemTimestamp(int nSeconds) {
    setup(nSeconds);
  }  // End of contructor.

  private void setup(int nSeconds) {
    long    lSeconds = (long) nSeconds;  // Cast the int to a long.

    m_date           = new Date(lSeconds * 1000);
    DateFormat df    = DateFormat.getDateTimeInstance(DateFormat.FULL,
      DateFormat.FULL, Locale.US);
    m_sLocalDate     = df.format(m_date);
    TimeZone   tzGMT = TimeZone.getTimeZone("GMT");
    df.setTimeZone(tzGMT);
    m_sUTCDate       = df.format(m_date);

    parseFormattedDateString(m_sLocalDate, m_alLocal, true);
    parseFormattedDateString(m_sUTCDate, m_alUTC, false);
  }  // End of method setup

  /**
   * This method parses the values contained within the formatted date string
   * sDate, which should have been created using class DateFormat using its
   * full context and a U.S. locale.  The format should be as follows:
   * "DDDDDD, MMMMM dd, YYYY hh:mm:ss HH ZZZ",
   * - DDDDDD is the full weekday name
   * - MMMMM  is the full month name
   * - dd     is the day of the month
   * - YYYY   is the 4-digit year
   * - hh     is the hour (1-12)
   * - mm     is the minute of the hour (00-59)
   * - HH     is the meridian (AM or PM)
   * - ZZZ    is the timezone
   * @param sDate formatted date to parse.
   * @param al    ArrayList class to store parsed numeric values.
   * @param bCheckDST flag indicating whether daylight savings time influenced
   * the generation of the timestamp.
   */
  private void parseFormattedDateString(String sDate, ArrayList al, boolean
      bCheckDST) {
    int             nWeekDay;
    int             nDay;
    int             nYear;
    int             nMonth;
    int             nHour;
    int             nMin;
    int             nSec;
    int             nMeridianOffset;
    int             i              = 0;
    StringTokenizer st             = new StringTokenizer(sDate, " :");

    // Weekday
    nWeekDay = convertName(st.nextToken(), "Sun Mon Tue Wed Thu Fri Sat");
    // Month
    nMonth = convertName(st.nextToken(), 
      "Jan Feb Mar Apr May Jun Jul Aug Sep Oct Nov Dec");
    // Day
    try {
      // The last character is always a comma, which cannot be parsed; so it is
      // necessary to read a substring of the token instead.
      String sDay = st.nextToken();
      nDay = Integer.parseInt(sDay.substring(0, sDay.length() - 1));
    } catch(NumberFormatException e) { nDay = -1; }
    // Year
    try {
      nYear = Integer.parseInt(st.nextToken());
    } catch(NumberFormatException e) { nYear = -1; }
    // Hour--cannot be posted until meridian is known.
    try {
      nHour = Integer.parseInt(st.nextToken());
    } catch(NumberFormatException e) { nHour = -1; }
    // Minute--cannot be posted until the hour is posted
    try {
      nMin = Integer.parseInt(st.nextToken());
    } catch(NumberFormatException e) { nMin = -1; }
    // Second--cannot be posted until the hour is posted
    try {
      nSec = Integer.parseInt(st.nextToken());
    } catch(NumberFormatException e) { nSec = -1; }
    // Meridian--used to set hour to 24-hour clock.
    nMeridianOffset = convertName(st.nextToken(), "AM PM");
    if(nMeridianOffset > 0) {
      nMeridianOffset--;  // Make sure is a zero or one
      nHour = (nHour % 12) + (nMeridianOffset * 12);
    }  // End of if statement.

    // If a check for Daylight Savings Time needs to be made, then the values
    // calculated by this class will have to be adjusted to local standard time
    // to conform the Aviation Algorithm requirements.
    if(bCheckDST) {
      Calendar cal   = new GregorianCalendar(nYear, nMonth, nDay, nHour, 
        nMin, nSec);
      /*
      Calendar cal   = 
          new GregorianCalendar(TimeZone.getTimeZone("America/Phoenix"));
      */
      // Get the DST offset in minutes.
      int     nDstOffset = cal.get(Calendar.DST_OFFSET)/(60 * 1000);
      // log.info("Timestamp nDstOffset = " + nDstOffset);
      boolean bChange    = false;
      if(nDstOffset > 0) {
        if(nDstOffset < 60) {
          nMin -= nDstOffset;
          if(nMin < 0) {
            nMin += 60;
            nHour--;
          }  // End of if statement.
        }  // End of if statement.
        else {
          nHour--;
        }  // End of if statement.
        if(nHour < 0) {
          nHour += 24;
          nDay--;
          nWeekDay--;
          if(nWeekDay < 1) {
            nWeekDay = 7;
          }  // End of if Statement.
          bChange = true;
        }  // End of if statement.
      }  // End of if statement.
      if(bChange) {
        if(nDay < 1) {
          nMonth--;
          if(nMonth < 1) {
            nMonth = 12;
            nYear--;
          }  // End of if statement.
          nDay = getDaysInMonth(nYear, nMonth);
        }  // End of if statement.
      }  // End of if statement.
    }  // End of if statement.

    /*
    log.info("Timestamp = " + nWeekDay + ", " + nMonth + "/" + 
      nDay + "/" + nYear + " " + nHour + ":" + nMin + ":" + nSec
       + " from " + sDate);
    */

    al.add(i++, new Integer(nWeekDay));
    al.add(i++, new Integer(nMonth));
    al.add(i++, new Integer(nDay));
    al.add(i++, new Integer(nYear));
    al.add(i++, new Integer(nHour));
    al.add(i++, new Integer(nMin));
    al.add(i++, new Integer(nSec));
  }  // End of method parseFormattedDateString

  public String toString() {
    return m_sLocalDate;
  }  // End of method toString.

  public String toUTCString() {
    return m_sUTCDate;
  }  // End of method toUTCString

  public int getYear() {
    return getValue(YEAR);
  }  // End of method getHour.

  public int getMonth() {
    return getValue(MONTH);
  }  // End of method getHour.

  public String getMonthName() {
    return getMonthName(getMonth());
  }  // End of method getMonthName

  public String getMonthName(int nMonth) {
    final String [] rgsMonths = { 
      "Jan", "Feb", "Mar", "Apr", "May", "Jun", 
      "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"
    };

    return nMonth > 0 && nMonth < 13 ? rgsMonths[nMonth - 1] : "ERR";
  }  // End of method getMonthName

  public int getDay() {
    return getValue(DAY);
  }  // End of method getHour.

  public int getWeekday() {
    return getValue(WEEKDAY);
  }  // End of method getHour.

  public int getHour() {
    return getValue(HOUR);
  }  // End of method getHour.

  public int getMin() {
    return getValue(MINUTE);
  }  // End of method getHour.

  public int getSec() {
    return getValue(SECOND);
  }  // End of method getHour.

  public String getSecString() {
    return getSec() + ".0";
  }  // End of method getSecString

  public int getValue(int nValueCode) {
    return nValueCode >= 0 && nValueCode < m_alLocal.size() ?
      ((Integer) m_alLocal.get(nValueCode)).intValue() : -1;  
  }  // End of method getValue.

  public int getUTCValue(int nValueCode) {
    return nValueCode >= 0 && nValueCode < m_alUTC.size() ?
      ((Integer) m_alUTC.get(nValueCode)).intValue() : -1;  
  }  // End of method getUTCValue

  public String toZenoString() {
    String sDate = new String();

    DecimalFormat fmt    = new DecimalFormat ("00");
    StringBuffer  buffer = new StringBuffer ();
    FieldPosition pos    = new FieldPosition (0);
    buffer.setLength(0);
    fmt.format (getYear() % 100, buffer, pos);
    sDate = buffer.toString() + "/";
    buffer.setLength(0);
    fmt.format (getMonth(), buffer, pos);
    sDate += (buffer.toString() + "/");
    buffer.setLength(0);
    fmt.format (getDay(), buffer, pos);
    sDate += (buffer.toString() + " ");
    buffer.setLength(0);
    fmt.format (getHour(), buffer, pos);
    sDate += (buffer.toString() + ":");
    buffer.setLength(0);
    fmt.format (getMin(), buffer, pos);
    sDate += (buffer.toString() + ":");
    buffer.setLength(0);
    fmt.format (getSec(), buffer, pos);
    sDate += (buffer.toString());

    return sDate;  
  }  // End of method toZenoString

  public String toUTCZenoString() {
    String sDate = new String();

    DecimalFormat fmt    = new DecimalFormat ("00");
    StringBuffer  buffer = new StringBuffer ();
    FieldPosition pos    = new FieldPosition (0);
    buffer.setLength(0);
    fmt.format (getUTCValue(YEAR) % 100, buffer, pos);
    sDate = buffer.toString() + "/";
    buffer.setLength(0);
    fmt.format (getUTCValue(MONTH), buffer, pos);
    sDate += (buffer.toString() + "/");
    buffer.setLength(0);
    fmt.format (getUTCValue(DAY), buffer, pos);
    sDate += (buffer.toString() + " ");
    buffer.setLength(0);
    fmt.format (getUTCValue(HOUR), buffer, pos);
    sDate += (buffer.toString() + ":");
    buffer.setLength(0);
    fmt.format (getUTCValue(MINUTE), buffer, pos);
    sDate += (buffer.toString() + ":");
    buffer.setLength(0);
    fmt.format (getUTCValue(SECOND), buffer, pos);
    sDate += (buffer.toString());

    return sDate + " UTC";  
  }  // End of method toZenoString

  public String toTimeString() {
    String sTime = new String();

    DecimalFormat fmt    = new DecimalFormat ("00");
    StringBuffer  buffer = new StringBuffer ();
    FieldPosition pos    = new FieldPosition (0);

    buffer.setLength(0);
    fmt.format (getHour(), buffer, pos);
    sTime  = (buffer.toString() + ":");
    buffer.setLength(0);
    fmt.format (getMin(), buffer, pos);
    sTime += (buffer.toString());
    /*
    sTime += (buffer.toString() + ":");
    buffer.setLength(0);
    fmt.format (nSec, buffer, pos);
    sTime += (buffer.toString());
    */
    
    return sTime;  
  }  // End of method toTimeString

  public String toMetarUTCString() {
    String sDate         = new String();
    
    DecimalFormat fmt    = new DecimalFormat ("00");
    StringBuffer  buffer = new StringBuffer ();
    FieldPosition pos    = new FieldPosition (0);

    buffer.setLength(0);
    fmt.format (getUTCValue(DAY), buffer, pos);
    sDate = buffer.toString();
    buffer.setLength(0);
    fmt.format (getUTCValue(HOUR), buffer, pos);
    sDate += buffer.toString();
    buffer.setLength(0);
    fmt.format (getUTCValue(MINUTE), buffer, pos);
    sDate += (buffer.toString() + "Z");
    
    return sDate;
  }  // End of method toMetarUTCString

  private int convertName(String sName, String sAllNames) {
    StringTokenizer st          = new StringTokenizer(sAllNames);
    String          token;
    int             i           = 1;
    int             nCode       = -1;

    while(st.hasMoreTokens() && nCode == -1) {
      token = st.nextToken();
      if(sName.matches("^" + token + "([,\\p{Alpha}\\n\\r])*")) {
        nCode = i;
      }  // End of if statement.
      i++;
    }  // End of while loop.

    return nCode;
  }  // End of method convertName

  public boolean isLeapYear(int nYear) {
    return (nYear % 4 == 0 && nYear % 100 != 0) || nYear % 400 == 0;    
  }  // End of method isLeapYear

  public boolean isLastDayOfMonth() {
    return getDay() == getDaysInMonth(getYear(), getMonth());
  }  // End of method isLastDayOfMonth

  public int getDaysInMonth(int nYear, int nMonth) {
    final int [][] rgrgnMonthDays = {
      { 31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31 },  
      { 31, 29, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31 }  
    };
    return nMonth > 0 && nMonth < 13 ? 
      rgrgnMonthDays[isLeapYear(nYear) ? 1 : 0][nMonth - 1] : -1;
  }  // End of method getDaysInMonth

  public boolean isSynoptic(int nMinuteOffset) {
    boolean bIsSynoptic = false;
    if(nMinuteOffset == 0) {
      bIsSynoptic = getHour() % 6 == 0;
    }  // End of if statement.
    else {
      bIsSynoptic = (getHour() % 6 == 5) && (getMin() == nMinuteOffset);
    }  // End of else statement.

    return bIsSynoptic;
  }  // End of method isTimeSynoptic
}  // End of class Timestamp.
