// $Id: ScheduledEvent.java 1938 2005-11-03 23:22:52Z mhart $
package org.coastal.util;

/* ScheduledEvent.java

   written by Marc Singer
   19 Sep 2003
   modified by Michael Hart

   Copyright (C) 2003 The Buici Company

   -----------
   DESCRIPTION
   -----------

   Event object for Scheduler

*/

public class ScheduledEvent extends PrioritizedTime {
  Runnable m_runnable  = null;
  Interval m_interval  = null;  // Interval for repeating event
  boolean  m_bKill     = false; // Flag to indicate whether to end this event.
  String   m_sIdentity = "";

  // Prioritized, recurring event, aligned
  public ScheduledEvent(Runnable runnable, Interval interval) {
    super();
    m_runnable = runnable;
    m_interval = interval;
    calc ();
  }  // End of contructor

  // Prioritized, recurring event, aligned
  public ScheduledEvent(Runnable runnable, Interval interval, int priority) {
    super(priority);
    m_runnable = runnable;
    m_interval = interval;
    calc ();
  }  // End of constructor

  // Prioritized, recurring event, aligned
  public ScheduledEvent(Runnable runnable, Interval interval, int priority,
     String sIdentity) {
    super(priority);
    m_runnable = runnable;
    m_interval = interval;
    if(sIdentity != null) {
      m_sIdentity = sIdentity;
    }  // End of if statement.
    calc ();
  }  // End of constructor

  // One shot event
  public ScheduledEvent(Runnable runnable, long ms) { 
    super(ms);
    m_runnable = runnable;
  }  // End of constructor

  void calc () {
    try {
      long msBasis = m_interval.frequency ()*1000;
      if (msBasis == 0) {
        return;
      }  // End of if statement.
      long msOffset = m_interval.offset ()*1000;
      if (msOffset > msBasis)	// Very important check
        msOffset = 0;

      long msNow = System.currentTimeMillis ();
      // ++delta if msOffset < 0
      setTime(((msNow - msOffset)/msBasis + 1)*msBasis + msOffset);
            
      // The apparent subtraction of msOffset followed by adding msOffset
      // back into m_msEvent effectively cancelled out msOffset.  The
      // subtraction portion from msNow has been removed.
      // m_msEvent = (msNow/msBasis + 1)*msBasis + msOffset;
      // if (m_msEvent < msNow)
      //   m_msEvent += msBasis;
      // if (m_msEvent < msNow)
      //   m_msEvent += msBasis;
    } catch (Exception ex) {
       setTime(0);
    }  // End of catch statement.
  }  // End of method calc

  public long event_time () {
    return time();
  }  // End of method event_time

  public Runnable runnable () {
    return m_runnable;
  }  // End of method runnable

  public String toString () {
    return time()/1000 + "," + priority() + " (" 
      + (time() - System.currentTimeMillis ())/1000 + ")";
  }  // End of toString

  public void kill() {
    m_bKill = true;
  }  // End of method kill

  public boolean isKilled() {
    return m_bKill;
  }  // End of method isKilled

  public String identity() {
    return m_sIdentity;
  }  // End of method identity
}  // End of class ScheduledEvent
