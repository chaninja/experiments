/*
 * Created on Mar 23, 2005
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package org.coastal.util;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;

import org.apache.log4j.FileAppender;
import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.apache.log4j.SimpleLayout;
import org.python.core.PyObject;
import org.python.util.PythonInterpreter;

/**
 * @author rboyd
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class Dbg {
    private static Logger logger = null;
    private static PythonInterpreter interp = new PythonInterpreter();
    private static PyObject y = null;

    private static void initLogger(){
        String root = UTIL.currentDirectory();
        String logPath = "res/log/";
        String fullPath = root + "/" + logPath;
        FileAppender appender = null;
        SimpleLayout layout = new SimpleLayout();
        try {
           appender = new FileAppender(layout, fullPath + "LOG_DEBUG.txt", false);
       } catch (IOException e) {
           e.printStackTrace();
       }
        logger.addAppender(appender);
        logger.setLevel(Level.DEBUG);
    }
    
    public static Logger logger(){
        if(logger == null){
            logger = Logger.getLogger(Dbg.class);
            initLogger();
        }
        return logger;
    }
    
    public static void log(String valu){
        Dbg.logger().debug(valu);
    }
    
    public static void log(String lbl, String valu){
        Dbg.logger().debug(lbl + " " + valu);
    }
    
    public static void logTime(String lbl, String valu){
    	logger().debug(System.currentTimeMillis() + " " + lbl + " " + valu);
    }
    
    public static void pylogDblTime(String lbl, double valu){
    	interp.set("x", new Double(valu));
        interp.exec("y = str(x)");
        y = interp.get("y");
        logger().debug(System.currentTimeMillis() + " " + lbl + " " + y);
    }
    
    public static void pylog(Object valu){
        interp.set("x", valu);
        interp.exec("y = str(x)");
        y = interp.get("y");
        logger().debug(y);
    }
    
    public static void pylogObj(String lbl, Object valu){
        interp.set("x", valu);
        interp.exec("y = str(x)");
        y = interp.get("y");
        logger().debug(lbl + " " + y);
    }
    
    public static void pylogInt(String lbl, int valu){
        interp.set("x", new Integer(valu));
        interp.exec("y = str(x)");
        y = interp.get("y");
        logger().debug(lbl + " " + y);
    }
    
    public static void pylogDbl(double valu){
        interp.set("x", new Double(valu));
        interp.exec("y = str(x)");
        y = interp.get("y");
        logger().debug(y);
    }
    
    public static void pylogDbl(String lbl, double valu){
        interp.set("x", new Double(valu));
        interp.exec("y = str(x)");
        y = interp.get("y");
        logger().debug(lbl + " " + y);
    }
    
    public static void pylogDbl(String lbl, double[] valu){
        ArrayList aLst = new ArrayList();
        for(int i=0; i<valu.length; i++){
            aLst.add(new Double(valu[i]));
        }
        interp.set("x", aLst);
        interp.exec("y = str(x)");
        y = interp.get("y");
        logger().debug(lbl + " " + y);
    }
    
    public static void pylogALst(String lbl, ArrayList aLst){
        interp.set("x", aLst);
        interp.exec("y = str(x)");
        y = interp.get("y");
        logger().debug(lbl + " " + y);
    }
    
    public static void brk(){
        logger().debug("");
        logger().debug("---------------");
        logger().debug("");
    }
    
    public static void bool(String lbl, boolean valu){
        logger().debug(lbl + " " + new Boolean(valu));
    }
    
    public static void logDate(String valu){
        Date today = new Date();
        Dbg.log(today.toString(), valu);
    }
    
    public static void pylogDateObj(Object obj){
        Date today = new Date();
        Dbg.pylogObj(today.toString(), obj);
    }
    
    public static void pylogDateLblObj(String lbl, Object obj){
        Date today = new Date();
        String combo = today.toString() + ": " + lbl;
        Dbg.pylogObj(combo, obj);
    }
    
    public static void pylogDateLblALst(String lbl, ArrayList valu){
        Date today = new Date();
        String combo = today.toString() + ": " + lbl;
        Dbg.pylogALst(combo, valu);
    }
    
    public static void pylogMap(String lbl, HashMap _map){
        interp.set("x", _map);
        interp.exec("y = str(x)");
        y = interp.get("y");
        logger().debug(lbl + " " + y);
    }
 
    public static void main(String[] args) {
    }
}
