package org.coastal.util.file;

import java.io.File;

import org.apache.log4j.Logger;
import static org.coastal.util.file.DirectoryHelper.DeleteMode.DELETE;
import static org.coastal.util.file.DirectoryHelper.DeleteMode.DELETE_ONLY_IF_EMPTY;

public class DirectoryHelper {
    public enum DeleteMode { DELETE, DELETE_ONLY_IF_EMPTY }
    public final static Logger logger = Logger.getLogger(DirectoryHelper.class);

    /**
     * Convenience method to check if a directory is empty.  Safe for use with
     * non-directories (always returns true).  
     * @param file the directory to check
     * @return true if file is an empty directory or not a directory, false if not empty
     */
    public static boolean isEmpty(File file) {
        if(file == null) {
            throw new IllegalArgumentException("file must be non-null");
        }
        String[] filenames = file.list();
        return filenames == null || filenames.length == 0;
    }
    
    /**
     * Deletes a directory, recursively.  
     * The directory does not have to be empty.
     * This is differs from Java's built-in <code>{@link File#delete()}</code> which <em>does not</em> delete recursively and <em>requires</em> directory be empty. 
     * @param directory the directory to delete
     * @param deleteMode the mode of deletion
     * @return  <code>true</code> if and only if the directory and any sub-directories and files are
     *          successfully deleted; <code>false</code> otherwise
     * @throws  SecurityException
     *          If a security manager exists and its <code>{@link
     *          java.lang.SecurityManager#checkDelete}</code> method denies
     *          delete access to the file
     * @see File#delete()
     */
    public static boolean delete(File directory, DeleteMode deleteMode) {
        boolean result = true;
        
        if(directory == null) {
            throw new IllegalArgumentException("directory must be non-null");
        }
        if(directory.exists()) {
            if(!directory.isDirectory()) {
                throw new IllegalArgumentException(directory + " must be a directory");
            }
    
            File[] subdirectories = directory.listFiles(DirectoryFileFilter.getInstance());
            for (File subdirectory : subdirectories) {
                result &= delete(subdirectory, deleteMode);
            }
            
            boolean deleteAllowed = isDeleteAllowed(directory, deleteMode);
            result &= deleteAllowed;  //because the result of true applies if and only if the directory was deleted
            if(deleteAllowed) {
                for (File file : directory.listFiles()) {
                    if(logger.isDebugEnabled()) {
                        logger.debug("deleting file " + file);
                    }
                    result &= file.delete();
                }
                if(logger.isDebugEnabled()) {
                    logger.debug("deleting directory " + directory);
                }
                result &= directory.delete();
            } else {
                if(logger.isDebugEnabled()) {
                    logger.debug("won't delete " + directory);
                }
            }
            
        }
        return result;
    }

    private static boolean isDeleteAllowed(File directory, DeleteMode deleteMode) {
        boolean deleteAllowed = false;
        if(deleteMode == DELETE) {
            deleteAllowed = true;
        } else if(deleteMode == DELETE_ONLY_IF_EMPTY) {
            if(isEmpty(directory)) {
                deleteAllowed = true;
            } else {
                deleteAllowed = false;
            }
        }
        return deleteAllowed;
    }
}
