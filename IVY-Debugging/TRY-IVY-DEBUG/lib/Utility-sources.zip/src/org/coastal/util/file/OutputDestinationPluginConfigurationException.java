package org.coastal.util.file;

/**
 * @author mchristianson
 *
 */
/**
 * Indicates an <code>{@link OutputDestinationPlugin}</code> had a 
 * config problem that prevented it from working properly.  
 * @author mchristianson
 *
 */
public class OutputDestinationPluginConfigurationException extends Exception {
    private static final long serialVersionUID = 5668214643759428005L;

	public OutputDestinationPluginConfigurationException() {
        super();
    }

    public OutputDestinationPluginConfigurationException(String message) {
        super(message);
    }

    public OutputDestinationPluginConfigurationException(Throwable cause) {
        super(cause);
    }

    public OutputDestinationPluginConfigurationException(String message, Throwable cause) {
        super(message, cause);
    }
}
