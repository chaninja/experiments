package org.coastal.util.file;
import ghm.follow.FileFollower;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

import org.apache.log4j.BasicConfigurator;
import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.coastal.util.PropertiesLoader;

/**
 * This class can 'follow' a text file, assmebling that file's
 * characters into Strings and sending them to instances of 
 * <code>{@link OutputDestinationPlugin}</code>. The behavior of this class 
 * is inspired by the '<code>-f</code>' (follow) flag of the UNIX command '<code>tail</code>'.
 * Example usage:
 * <pre>
 * LogFileWatcher fileWatcher = new LogFileWatcher(properties);  //Properties object is optional
 * fileWatcher.init();
 * </pre> 
 * @author mchristianson
 *
 */
public class FileWatcher {
    private final static Logger logger = Logger.getLogger(FileWatcher.class);
    private static final String PROPERTIES_FILENAME = "FileWatcher.properties";
    private Properties properties;
    private FileFollower follower;
    
    /**
     * Constructs a <code>LogFileWatcher</code> without giving a <code>Properties</code>
     * file.  It will attempt to load its default <code>Properties</code> file 
     * from the classpath as a streamed resource.
     * @throws IOException if there is a problem loading the default <code>Properties</code> file 
     */
    public FileWatcher() throws IOException {
        Properties properties = PropertiesLoader.load(PROPERTIES_FILENAME);
        setProperties(properties);
    }
    
    /**
     * Constructs a <code>LogFileWatcher</code> with the given <code>Properties</code> file.
     * @param properties
     */
    public FileWatcher(Properties properties) {
        setProperties(properties);
    }
    
    /**
     * Sets the <code>Properties</code> file.  Useful if using a no-args constructor
     * or updating in tandem with <code>{@link #stop()}</code> or <code>{@link #stopAndWait()}</code>.
     * @param properties
     */
    public void setProperties(Properties properties) {
        this.properties = properties;
    }

    /**
     * Returns a copy of the current <code>Properties</code>.
     */
    public Properties getProperties() {
        return new Properties(properties);
    }

    /**
     * Initializes the instance; begins watching the configured file and calling
     * <code>clear()</code> and <code>print(String)</code> on the configured
     * <code>{@link OutputDestinationPlugin}</code>s.
     * @throws OutputDestinationPluginConfigurationException
     * @see OutputDestinationPlugin
     * @see OutputDestinationPlugin#clear()
     * @see OutputDestinationPlugin#print(String)
     */
    public void init() throws OutputDestinationPluginConfigurationException {
        logger.info("init()");
        String[] notifierPluginsStrArray = new String[0];

        String filename = properties.getProperty("filename");
        logger.info("Will follow file: " + filename);
        File file = new File(filename);
        if(!file.exists() || !file.canRead()) {
            logger.warn("Can't currently read from the file.  Maybe it will show up later?");
        }
        
        String notifierPluginsStr = properties.getProperty("notifierPlugins");  //"org.coastal.file.VGSSErrorNotifier"
        if(notifierPluginsStr != null) {
            notifierPluginsStrArray = notifierPluginsStr.split(",\\s*");
        }
        
        List<OutputDestinationPlugin> notifierPlugins = new ArrayList<OutputDestinationPlugin>(notifierPluginsStrArray.length);
        for (int i = 0; i < notifierPluginsStrArray.length; i++) {
            String className = notifierPluginsStrArray[i];
            logger.info("Loading notifier plugin: " + className);
            try {
                Class<?> name = Class.forName(className);
                OutputDestinationPlugin plugin = (OutputDestinationPlugin) name.newInstance();
                plugin.setProperties(properties);
                plugin.init();
                notifierPlugins.add(plugin);     //get notified
            } catch (ClassNotFoundException cnfe) {
                logger.error("Could not load plugin", cnfe);
            } catch (InstantiationException ie) {
                logger.error("Could not load plugin", ie);
            } catch (IllegalAccessException iae) {
                logger.error("Could not load plugin", iae);
            } catch (OutputDestinationPluginConfigurationException odpce) {
                logger.error("Could not load plugin", odpce);
            }                
        }
        OutputDestinationPlugin[] outputDestinations = notifierPlugins.toArray(new OutputDestinationPlugin[notifierPlugins.size()]);
        
        if(outputDestinations.length > 0) {
            follower = new FileFollower(file, outputDestinations);
            logger.info("Starting follow process with " + outputDestinations.length + " plugins on " + file.getAbsolutePath());
            follower.start();
        } else {
            throw new OutputDestinationPluginConfigurationException("Nothing to do; no plugins have been loaded, so there's no point in following " + file.getAbsolutePath());
        }
    }
    
    /**
    Cause this <code>LogFileWatcher</code> to stop following the configured file 
    after it flushes the characters it's currently reading to all its
    OutputDestinations.
     */  
    public void stop() {
        if(follower != null) {
            follower.stop();
        }
    }

    /**
    Like {@link #stop()}, but this method will not exit until the thread which
    is following the file has finished executing (i.e., stop synchronously).
     */
    public void stopAndWait() throws InterruptedException {
        if(follower != null) {
            follower.stopAndWait();
        }
    }
    
    public static void main(String...args) throws IOException, OutputDestinationPluginConfigurationException {
        BasicConfigurator.configure();
        logger.setLevel(Level.ALL);
        FileWatcher logWatcher = new FileWatcher();
        logWatcher.init();
    }
}