package org.coastal.util;

/**
 * <p>Title: LinkedAbacus</p>
 * <p>Description: Test for running Aviation Intercept Algorithms</p>
 * <p>Copyright: Copyright (c) 2003 - 2004</p>
 * <p>Company: Coastal Environmental Systems</p>
 * @author Michael Hart
 * @version 1.0
 */

public class ConvertPressure extends ConvertUnits {
  public final int INCHES_OF_MERCURY    = 0;
  public final int HECTOPASCALS         = 1;  // Same as millibars
  public final int KILOPASCALS          = 2;
  public final int PASCALS              = 3;
  public final int BARS                 = 4;
  public final int MILLIBARS            = 5;
  public final int KG_PER_SQUARE_CM     = 6;
  public final int ATMOSPHERES          = 7;
  public final int NEWTONS_PER_SQUARE_M = 8;  // Same as pascals
  public final int MILLIBAR             = 9;  // Same as millibars
  
  final double     HECTOPASCALS_TO_INHG = 0.02953;
  final double     INHG_TO_KG_PER_SQ_CM = 0.03453;
  final double     ATMOSPHERE_TO_BARS   = 1.01325;

  final String []  m_rgsUnitsNames      = {
    "inHg", "hPa", "kPa", "Pa", "bars", "mbars", "kg/cm^2", "atm", "N/m^2", "mb"  
  };

  public int numberOfUnitNames() {
    return m_rgsUnitsNames.length;
  }  // End of method numberOfUnitNames

  public String unitName(int nIndex) {
    String sName = "";
    if(nIndex >= 0 && nIndex < numberOfUnitNames()) {
      sName = m_rgsUnitsNames[nIndex];
    }  // End of if statement.
    return sName;
  }  // End of method unitName

  public double convert(double dPressure, int nOldUnitsID, int nNewUnitsID) {
    double dConverted = dPressure;

    // Convert pressure into inches of mercury
    switch(nOldUnitsID) {
      case MILLIBAR:
      case MILLIBARS:
      case HECTOPASCALS: {
        dConverted = hectoPascalsToInchesMercury(dConverted);
        break;
      }  // End of case statement.      

      case KILOPASCALS: {
        dConverted = hectoPascalsToInchesMercury(dConverted*10.0);
        break;
      }  // End of case statement.      

      case NEWTONS_PER_SQUARE_M:
      case PASCALS: {
        dConverted = hectoPascalsToInchesMercury(dConverted/100.0);
        break;
      }  // End of case statement.

      case ATMOSPHERES: {
        dConverted *= ATMOSPHERE_TO_BARS;        
        // DON'T BREAK HERE!!!
      }  // End of case statement.
      case BARS: {
        dConverted = hectoPascalsToInchesMercury(dConverted*1000.0);
        break;
      }  // End of case statement.

      case KG_PER_SQUARE_CM: {
        dConverted /= INHG_TO_KG_PER_SQ_CM;
        break;
      }  // End of case statement.
    }  // End of switch statement.
    // Convert inches of mercury into new units
    switch (nNewUnitsID) {
      case MILLIBAR:
      case MILLIBARS:
      case HECTOPASCALS: {
        dConverted = inchesMercuryToHectoPascals(dConverted);
        break;
      }  // End of case statement.

      case KILOPASCALS: {
        dConverted = inchesMercuryToHectoPascals(dConverted)/10.0;
        break;
      }  // End of case statement.      

      case NEWTONS_PER_SQUARE_M:
      case PASCALS: {
        dConverted = inchesMercuryToHectoPascals(dConverted)*100.0;
        break;
      }  // End of case statement.

      case ATMOSPHERES:
      case BARS: {
        dConverted = inchesMercuryToHectoPascals(dConverted)/1000.0;
        if(nNewUnitsID == ATMOSPHERES) {
          dConverted /= ATMOSPHERE_TO_BARS;
        }  // End of if statement.
        break;
      }  // End of case statement.

      case KG_PER_SQUARE_CM: {
        dConverted *= INHG_TO_KG_PER_SQ_CM;
        break;
      }  // End of case statement.
    }  // End of switch statement.

    return dConverted;
  }  // End of method convert

  double hectoPascalsToInchesMercury(double dValue) {
    return dValue * HECTOPASCALS_TO_INHG;
  }  // End of method hectoPascalsToInchesMercury

  double inchesMercuryToHectoPascals(double dValue) {
    return dValue / HECTOPASCALS_TO_INHG;
  }  // End of method hectoPascalsToInchesMercury

  public boolean equivalentUnits(int unitsCode, int unitsCode2) {
		if ((unitsCode == 1 || unitsCode == 9 || unitsCode == 5 ) &&
				(unitsCode2 == 1 || unitsCode2 == 9 || unitsCode2 == 5 ))	
			return true;
	return false;
  }
}  // End of class ConvertPressure
